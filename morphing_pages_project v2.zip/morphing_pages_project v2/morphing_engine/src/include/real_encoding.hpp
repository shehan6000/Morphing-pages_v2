// real_encoding.hpp
//
// Real zlib compression, C++ port of the Python prototype's
// encoding.py. This is the pipeline actually exercised by
// engine_benchmark.cpp's measured numbers — no placeholder, unlike
// morphing_pages_ext/src/include/temperature.hpp's PlaceholderEncode.
#pragma once

#include <cstdint>
#include <cstring>
#include <stdexcept>
#include <vector>
#include <zlib.h>

namespace morphing_pages {

enum class PageState : uint8_t { HOT = 0, WARM = 1, COLD = 2 };

inline int CompressionLevelFor(PageState state) {
  switch (state) {
    case PageState::HOT: return 0;
    case PageState::WARM: return 3;
    case PageState::COLD: return 9;
  }
  return 0;
}

// Delta-transform 8-byte double slots before COLD compression, matching
// encoding.py::_delta_encode exactly.
inline std::vector<uint8_t> DeltaEncode(const std::vector<uint8_t> &raw) {
  size_t n = raw.size() / sizeof(double);
  if (n == 0) return raw;
  std::vector<double> vals(n);
  std::memcpy(vals.data(), raw.data(), n * sizeof(double));
  std::vector<double> out(n);
  out[0] = vals[0];
  for (size_t i = 1; i < n; i++) out[i] = vals[i] - vals[i - 1];
  std::vector<uint8_t> result(n * sizeof(double));
  std::memcpy(result.data(), out.data(), result.size());
  return result;
}

inline std::vector<double> DeltaDecode(const std::vector<uint8_t> &payload, size_t n) {
  std::vector<double> deltas(n);
  std::memcpy(deltas.data(), payload.data(), n * sizeof(double));
  std::vector<double> vals(n);
  if (n > 0) vals[0] = deltas[0];
  for (size_t i = 1; i < n; i++) vals[i] = vals[i - 1] + deltas[i];
  return vals;
}

inline std::vector<uint8_t> RealEncode(const std::vector<uint8_t> &raw, PageState state) {
  int level = CompressionLevelFor(state);
  if (level == 0) return raw;

  std::vector<uint8_t> payload = (state == PageState::COLD) ? DeltaEncode(raw) : raw;

  uLongf bound = compressBound(static_cast<uLong>(payload.size()));
  std::vector<uint8_t> out(bound);
  uLongf out_len = bound;
  int rc = compress2(out.data(), &out_len, payload.data(),
                      static_cast<uLong>(payload.size()), level);
  if (rc != Z_OK) throw std::runtime_error("zlib compress2 failed");
  out.resize(out_len);
  return out;
}

// raw_size must be tracked by the caller (a real format would prefix a
// header with this; kept as an explicit parameter here for simplicity).
inline std::vector<uint8_t> RealDecode(const std::vector<uint8_t> &encoded,
                                        PageState state, size_t raw_size) {
  if (state == PageState::HOT) return encoded;

  std::vector<uint8_t> payload(raw_size);
  uLongf payload_len = static_cast<uLongf>(raw_size);
  int rc = uncompress(payload.data(), &payload_len, encoded.data(),
                       static_cast<uLong>(encoded.size()));
  if (rc != Z_OK) throw std::runtime_error("zlib uncompress failed");

  if (state != PageState::COLD) return payload;

  size_t n = raw_size / sizeof(double);
  std::vector<double> vals = DeltaDecode(payload, n);
  std::vector<uint8_t> result(n * sizeof(double));
  std::memcpy(result.data(), vals.data(), result.size());
  return result;
}

}  // namespace morphing_pages
