// fixed_schedule_persistent_page.hpp
//
// Real fixed-schedule baseline: compresses straight to COLD once a page
// has gone `compress_after_ticks` without a write, regardless of read
// pressure — mirroring TimescaleDB-style chunk compression jobs, now
// measured against real disk I/O instead of simulated. Any write forces
// an immediate, real decompress-and-rewrite back to HOT.
#pragma once

#include <vector>

#include "persistent_morphing_page.hpp"

namespace morphing_pages {

class FixedSchedulePersistentPage {
 public:
  FixedSchedulePersistentPage(BlockFile &file, std::vector<uint8_t> raw,
                               int compress_after_ticks)
      : raw_(std::move(raw)),
        compress_after_(compress_after_ticks),
        state_(PageState::HOT),
        ticks_since_write_(0),
        page_(file, raw_) {}

  void OnWrite() {
    ticks_since_write_ = 0;
    if (state_ != PageState::HOT) {
      page_.Transcode(PageState::HOT, raw_);
      state_ = PageState::HOT;
    }
  }

  void OnRead() { /* no-op: fixed schedule ignores read pressure entirely */ }

  void Tick() {
    ticks_since_write_++;
    if (state_ == PageState::HOT && ticks_since_write_ >= compress_after_) {
      page_.Transcode(PageState::COLD, raw_);
      state_ = PageState::COLD;
    }
  }

  std::vector<uint8_t> Read() { return page_.Read(); }
  PageState State() const { return state_; }
  BlockFile::Region CurrentRegion() const { return page_.SnapshotMeta()->region; }

 private:
  std::vector<uint8_t> raw_;
  int compress_after_;
  PageState state_;
  int ticks_since_write_;
  PersistentMorphingPage page_;
};

}  // namespace morphing_pages
