// block_file.hpp
//
// Real, file-backed block storage. No DuckDB, no simulation — a real
// file on disk, real pwrite/pread syscalls.
//
// HONEST LIMITATION: append-only, no free-list, no reclamation. Every
// Transcode() writes a brand-new region and never frees the old one.
// This is fine for a benchmark prototype (and is explicitly why we
// report BOTH physical file size and logical size below — see
// engine_benchmark.cpp) but is NOT production-grade: a real engine
// needs a free list and periodic compaction. Stated here rather than
// hidden, because it directly affects how "final storage" numbers from
// this engine should be read.
#pragma once

#include <atomic>
#include <cstdint>
#include <fcntl.h>
#include <stdexcept>
#include <string>
#include <unistd.h>
#include <vector>

namespace morphing_pages {

class BlockFile {
 public:
  explicit BlockFile(const std::string &path) {
    fd_ = open(path.c_str(), O_RDWR | O_CREAT | O_TRUNC, 0644);
    if (fd_ < 0) throw std::runtime_error("failed to open block file: " + path);
  }
  ~BlockFile() {
    if (fd_ >= 0) close(fd_);
  }
  BlockFile(const BlockFile &) = delete;
  BlockFile &operator=(const BlockFile &) = delete;

  struct Region {
    uint64_t offset;
    uint64_t length;
  };

  // Atomically reserves space at the end of the file (the only
  // serialization point — an atomic fetch_add, not a lock), then writes
  // via pwrite at that offset. pwrite is safe to call concurrently from
  // multiple threads writing to disjoint regions, since it takes an
  // explicit offset rather than relying on a shared file cursor.
  Region Append(const std::vector<uint8_t> &data) {
    uint64_t offset = physical_size_.fetch_add(data.size());
    ssize_t written = pwrite(fd_, data.data(), data.size(), static_cast<off_t>(offset));
    if (written < 0 || static_cast<size_t>(written) != data.size())
      throw std::runtime_error("short/failed pwrite");
    return Region{offset, data.size()};
  }

  // Real disk read via pread. Safe to call concurrently with no locking
  // at all — this is the actual, measured read path (real syscall, real
  // page-cache/disk round trip), not a simulated decode-time estimate.
  std::vector<uint8_t> Read(Region region) const {
    std::vector<uint8_t> buf(region.length);
    ssize_t got = pread(fd_, buf.data(), region.length, static_cast<off_t>(region.offset));
    if (got < 0 || static_cast<size_t>(got) != region.length)
      throw std::runtime_error("short/failed pread");
    return buf;
  }

  // Physical bytes ever written to this file — inflated by the
  // append-only, no-reclamation design (§ header comment above).
  uint64_t PhysicalSizeBytes() const { return physical_size_.load(); }

 private:
  int fd_ = -1;
  std::atomic<uint64_t> physical_size_{0};
};

}  // namespace morphing_pages
