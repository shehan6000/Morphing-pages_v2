// persistent_morphing_page.hpp
//
// The same copy-on-write discipline as morphing_pages_ext's
// morphing_page.hpp (concurrency-validated under ThreadSanitizer in the
// paper's §4.7), reapplied here to DISK-RESIDENT pages instead of
// in-memory canary-framed buffers. Transcode() encodes off to the side
// and writes it to disk via a real pwrite BEFORE the atomic pointer
// swap — so a reader that grabs a snapshot mid-transcode still reads a
// complete, valid on-disk region, never a partial one. Old regions are
// never overwritten (block_file.hpp is append-only), so a reader
// holding an old snapshot keeps working even after a swap.
#pragma once

#include <atomic>
#include <memory>
#include <vector>

#include "block_file.hpp"
#include "real_encoding.hpp"

namespace morphing_pages {

struct DiskEncodedPage {
  PageState state;
  BlockFile::Region region;
  size_t raw_size;
  uint64_t generation;
};

class PersistentMorphingPage {
 public:
  PersistentMorphingPage(BlockFile &file, std::vector<uint8_t> initial_raw)
      : file_(file), raw_size_(initial_raw.size()), generation_(0) {
    auto region = file_.Append(initial_raw);  // HOT = stored as-is
    auto page = std::make_shared<const DiskEncodedPage>(
        DiskEncodedPage{PageState::HOT, region, raw_size_, generation_.fetch_add(1)});
    current_.store(page, std::memory_order_release);
  }

  std::shared_ptr<const DiskEncodedPage> SnapshotMeta() const {
    return current_.load(std::memory_order_acquire);
  }

  // The actual measured read path: real pread + real zlib decode.
  std::vector<uint8_t> Read() const {
    auto meta = SnapshotMeta();
    auto encoded_bytes = file_.Read(meta->region);
    return RealDecode(encoded_bytes, meta->state, meta->raw_size);
  }

  void Transcode(PageState new_state, const std::vector<uint8_t> &raw_bytes) {
    auto encoded = RealEncode(raw_bytes, new_state);      // build off to the side
    auto region = file_.Append(encoded);                   // real disk write
    auto page = std::make_shared<const DiskEncodedPage>(
        DiskEncodedPage{new_state, region, raw_bytes.size(), generation_.fetch_add(1)});
    current_.store(page, std::memory_order_release);       // the atomic swap
  }

  PageState CurrentState() const {
    return current_.load(std::memory_order_acquire)->state;
  }

 private:
  BlockFile &file_;
  size_t raw_size_;
  std::atomic<uint64_t> generation_;
  std::atomic<std::shared_ptr<const DiskEncodedPage>> current_;
};

}  // namespace morphing_pages
