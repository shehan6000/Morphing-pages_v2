// temperature_tracked_persistent_page.hpp
//
// Same temperature/hysteresis state machine as the paper's §3.1-3.2,
// now driving REAL Transcode() calls (real zlib encode + real pwrite)
// on a disk-resident page, instead of the Python simulation's
// in-memory bookkeeping.
#pragma once

#include <mutex>
#include <vector>

#include "persistent_morphing_page.hpp"

namespace morphing_pages {

struct EngineTemperatureConfig {
  double decay = 0.90;
  double read_weight = 1.0;
  double write_weight = 3.0;
  double demote_threshold = 0.5;
  int hysteresis_ticks = 3;
};

class TemperatureTrackedPersistentPage {
 public:
  TemperatureTrackedPersistentPage(BlockFile &file, std::vector<uint8_t> raw,
                                    EngineTemperatureConfig cfg)
      : raw_(std::move(raw)),
        cfg_(cfg),
        state_(PageState::HOT),
        temperature_(cfg.write_weight),
        below_streak_(0),
        page_(file, raw_) {}

  void OnWrite() {
    std::lock_guard<std::mutex> lock(mutex_);
    temperature_ += cfg_.write_weight;
    below_streak_ = 0;
    if (state_ != PageState::HOT) {
      page_.Transcode(PageState::HOT, raw_);
      state_ = PageState::HOT;
    }
  }

  void OnRead() {
    std::lock_guard<std::mutex> lock(mutex_);
    temperature_ += cfg_.read_weight;
  }

  void Tick() {
    std::lock_guard<std::mutex> lock(mutex_);
    temperature_ *= cfg_.decay;
    if (temperature_ < cfg_.demote_threshold) {
      below_streak_++;
    } else {
      below_streak_ = 0;
    }
    if (below_streak_ >= cfg_.hysteresis_ticks) {
      if (state_ == PageState::HOT) {
        page_.Transcode(PageState::WARM, raw_);
        state_ = PageState::WARM;
      } else if (state_ == PageState::WARM) {
        page_.Transcode(PageState::COLD, raw_);
        state_ = PageState::COLD;
      }
      below_streak_ = 0;
    }
  }

  // Real read: no lock held here — matches the design already validated
  // under ThreadSanitizer in the paper's §4.7 (read path stays
  // independent of the bookkeeping mutex).
  std::vector<uint8_t> Read() { return page_.Read(); }

  BlockFile::Region CurrentRegion() const { return page_.SnapshotMeta()->region; }

  PageState State() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return state_;
  }

 private:
  std::vector<uint8_t> raw_;
  EngineTemperatureConfig cfg_;
  PageState state_;
  double temperature_;
  int below_streak_;
  mutable std::mutex mutex_;
  PersistentMorphingPage page_;
};

}  // namespace morphing_pages
