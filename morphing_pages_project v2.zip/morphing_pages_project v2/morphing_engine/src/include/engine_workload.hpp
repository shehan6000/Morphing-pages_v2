// engine_workload.hpp
//
// C++ port of the Python prototype's workload.py: write-then-decay
// trace generator. Not bit-for-bit identical to Python's Mersenne
// Twister output (std::mt19937 with the same seed produces different
// values than Python's random module), so this validates the same
// WORKLOAD SHAPE against real disk I/O, not a byte-identical replay of
// §4's exact numbers.
#pragma once

#include <algorithm>
#include <cmath>
#include <cstring>
#include <random>
#include <vector>

namespace morphing_pages {

enum class EventType { Write, Read };
struct TraceEvent {
  int tick;
  int page_id;
  EventType type;
};

inline std::vector<uint8_t> MakeRawPage(int n_values, unsigned seed) {
  std::mt19937 rng(seed);
  std::uniform_real_distribution<double> base_dist(10.0, 100.0);
  std::normal_distribution<double> noise(0.0, 1.5);
  double base = base_dist(rng);
  std::vector<double> vals(n_values);
  for (int i = 0; i < n_values; i++) vals[i] = base + noise(rng);
  std::vector<uint8_t> raw(n_values * sizeof(double));
  std::memcpy(raw.data(), vals.data(), raw.size());
  return raw;
}

inline std::vector<TraceEvent> GenerateTrace(int n_pages, int n_ticks,
                                              int write_burst_ticks = 5,
                                              int read_decay_ticks = 40,
                                              unsigned seed = 42) {
  std::mt19937 rng(seed);
  std::uniform_int_distribution<int> created_dist(0, std::max(1, n_ticks / 4));
  std::uniform_real_distribution<double> unit(0.0, 1.0);

  std::vector<int> created_at(n_pages);
  for (int p = 0; p < n_pages; p++) created_at[p] = created_dist(rng);

  std::vector<TraceEvent> trace;
  for (int tick = 0; tick < n_ticks; tick++) {
    for (int p = 0; p < n_pages; p++) {
      int age = tick - created_at[p];
      if (age < 0) continue;
      if (age < write_burst_ticks) {
        if (age == 0 || unit(rng) < 0.8) {
          trace.push_back({tick, p, EventType::Write});
        }
      } else if (age < write_burst_ticks + read_decay_ticks) {
        int decay_age = age - write_burst_ticks;
        double prob = 0.6 * std::pow(0.9, decay_age);
        if (unit(rng) < prob) {
          trace.push_back({tick, p, EventType::Read});
        }
      }
    }
  }
  return trace;
}

}  // namespace morphing_pages
