// engine_benchmark.cpp
//
// The real, from-scratch equivalent of the Python prototype's
// benchmark.py — but every number here comes from actual pwrite/pread
// syscalls and actual zlib compression, against actual files on disk.
// No DuckDB, no simulation, no stub types.
//
// Reports BOTH physical file size (inflated by block_file.hpp's
// append-only, no-reclamation design) and logical size (sum of
// currently-live region lengths) — conflating the two would overstate
// the real storage cost, since old superseded regions are never freed
// in this prototype. See block_file.hpp's header comment.
#include <chrono>
#include <cstdio>
#include <fstream>
#include <map>
#include <memory>
#include <vector>

#include "../src/include/block_file.hpp"
#include "../src/include/engine_workload.hpp"
#include "../src/include/fixed_schedule_persistent_page.hpp"
#include "../src/include/temperature_tracked_persistent_page.hpp"

using namespace morphing_pages;
using Clock = std::chrono::high_resolution_clock;

struct RunResult {
  double avg_read_latency_us = 0.0;
  uint64_t physical_bytes = 0;
  uint64_t logical_bytes = 0;
  uint64_t raw_bytes = 0;
  int total_writes = 0;
  int total_reads = 0;
};

RunResult RunAdaptive(int n_pages, int n_ticks, int page_n_values, const std::string &path) {
  BlockFile file(path);
  EngineTemperatureConfig cfg;
  std::map<int, std::unique_ptr<TemperatureTrackedPersistentPage>> pages;

  auto trace = GenerateTrace(n_pages, n_ticks);
  std::map<int, std::vector<TraceEvent>> by_tick;
  for (auto &e : trace) by_tick[e.tick].push_back(e);

  RunResult result;
  uint64_t raw_total = 0;
  std::vector<double> read_latencies;

  for (int tick = 0; tick < n_ticks; tick++) {
    auto it = by_tick.find(tick);
    if (it != by_tick.end()) {
      for (auto &e : it->second) {
        if (pages.find(e.page_id) == pages.end()) {
          auto raw = MakeRawPage(page_n_values, 1000 + e.page_id);
          raw_total += raw.size();
          pages[e.page_id] =
              std::make_unique<TemperatureTrackedPersistentPage>(file, raw, cfg);
        }
        if (e.type == EventType::Write) {
          pages[e.page_id]->OnWrite();
          result.total_writes++;
        } else {
          auto t0 = Clock::now();
          auto decoded = pages[e.page_id]->Read();  // real pread + real decode
          auto t1 = Clock::now();
          (void)decoded;
          pages[e.page_id]->OnRead();
          read_latencies.push_back(
              std::chrono::duration<double, std::micro>(t1 - t0).count());
          result.total_reads++;
        }
      }
    }
    for (auto &[id, pg] : pages) pg->Tick();
  }

  uint64_t logical = 0;
  for (auto &[id, pg] : pages) logical += pg->CurrentRegion().length;

  result.physical_bytes = file.PhysicalSizeBytes();
  result.logical_bytes = logical;
  result.raw_bytes = raw_total;
  if (!read_latencies.empty()) {
    double sum = 0;
    for (double v : read_latencies) sum += v;
    result.avg_read_latency_us = sum / read_latencies.size();
  }
  return result;
}

RunResult RunFixedSchedule(int n_pages, int n_ticks, int page_n_values,
                            const std::string &path, int compress_after) {
  BlockFile file(path);
  std::map<int, std::unique_ptr<FixedSchedulePersistentPage>> pages;

  auto trace = GenerateTrace(n_pages, n_ticks);
  std::map<int, std::vector<TraceEvent>> by_tick;
  for (auto &e : trace) by_tick[e.tick].push_back(e);

  RunResult result;
  uint64_t raw_total = 0;
  std::vector<double> read_latencies;

  for (int tick = 0; tick < n_ticks; tick++) {
    auto it = by_tick.find(tick);
    if (it != by_tick.end()) {
      for (auto &e : it->second) {
        if (pages.find(e.page_id) == pages.end()) {
          auto raw = MakeRawPage(page_n_values, 1000 + e.page_id);
          raw_total += raw.size();
          pages[e.page_id] =
              std::make_unique<FixedSchedulePersistentPage>(file, raw, compress_after);
        }
        if (e.type == EventType::Write) {
          pages[e.page_id]->OnWrite();
          result.total_writes++;
        } else {
          auto t0 = Clock::now();
          auto decoded = pages[e.page_id]->Read();
          auto t1 = Clock::now();
          (void)decoded;
          pages[e.page_id]->OnRead();
          read_latencies.push_back(
              std::chrono::duration<double, std::micro>(t1 - t0).count());
          result.total_reads++;
        }
      }
    }
    for (auto &[id, pg] : pages) pg->Tick();
  }

  uint64_t logical = 0;
  for (auto &[id, pg] : pages) logical += pg->CurrentRegion().length;

  result.physical_bytes = file.PhysicalSizeBytes();
  result.logical_bytes = logical;
  result.raw_bytes = raw_total;
  if (!read_latencies.empty()) {
    double sum = 0;
    for (double v : read_latencies) sum += v;
    result.avg_read_latency_us = sum / read_latencies.size();
  }
  return result;
}

int main() {
  const int n_pages = 50;
  const int n_ticks = 200;
  const int page_n_values = 1024;  // ~8KB, matches paper's original test size

  std::printf("=== Morphing Pages: real disk-backed engine benchmark ===\n");
  std::printf("(n_pages=%d, n_ticks=%d, page_n_values=%d -> ~%.1fKB/page)\n\n",
              n_pages, n_ticks, page_n_values, page_n_values * 8.0 / 1024.0);

  auto adaptive = RunAdaptive(n_pages, n_ticks, page_n_values, "/tmp/morphing_adaptive.bin");
  auto fixed = RunFixedSchedule(n_pages, n_ticks, page_n_values,
                                 "/tmp/morphing_fixed.bin", 20);
  // static = fixed-schedule with an unreachable compress_after threshold,
  // i.e. a page never crosses it within n_ticks, so it never leaves HOT.
  auto staticp = RunFixedSchedule(n_pages, n_ticks, page_n_values,
                                   "/tmp/morphing_static.bin", n_ticks * 10);

  std::printf("%-20s%-18s%-16s%-16s\n", "policy", "read_lat(us)", "logical_%raw",
              "physical_bytes");
  std::printf("--------------------------------------------------------------\n");
  std::printf("%-20s%-18.3f%-16.2f%-16lu\n", "adaptive", adaptive.avg_read_latency_us,
              100.0 * adaptive.logical_bytes / adaptive.raw_bytes,
              (unsigned long)adaptive.physical_bytes);
  std::printf("%-20s%-18.3f%-16.2f%-16lu\n", "fixed-schedule", fixed.avg_read_latency_us,
              100.0 * fixed.logical_bytes / fixed.raw_bytes,
              (unsigned long)fixed.physical_bytes);
  std::printf("%-20s%-18.3f%-16.2f%-16lu\n", "static-uncompressed", staticp.avg_read_latency_us,
              100.0 * staticp.logical_bytes / staticp.raw_bytes,
              (unsigned long)staticp.physical_bytes);

  double speedup = fixed.avg_read_latency_us / adaptive.avg_read_latency_us;
  std::printf("\nReal measured speedup (adaptive vs fixed-schedule): %.2fx\n", speedup);
  std::printf("\nreads: adaptive=%d fixed=%d static=%d | writes: adaptive=%d fixed=%d static=%d\n",
              adaptive.total_reads, fixed.total_reads, staticp.total_reads,
              adaptive.total_writes, fixed.total_writes, staticp.total_writes);

  return 0;
}
