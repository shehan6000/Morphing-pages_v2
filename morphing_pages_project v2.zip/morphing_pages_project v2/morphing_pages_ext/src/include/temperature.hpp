// temperature.hpp
//
// C++ port of the Python prototype's page.py: the temperature signal and
// hysteresis-guarded state machine (§3.1-3.2) that decides WHEN to call
// MorphingPage::Transcode(). Kept separate from morphing_page.hpp because
// the temperature policy is workload-tunable and should stay decoupled
// from the copy-on-write mechanism it drives.
#pragma once

#include <cstdint>
#include <mutex>
#include <vector>

#include "morphing_page.hpp"

namespace morphing_pages {

struct TemperatureConfig {
  double decay = 0.90;
  double read_weight = 1.0;
  double write_weight = 3.0;
  double demote_threshold = 0.5;
  int hysteresis_ticks = 3;
};

// Simple stand-in encoder matching the Python prototype's approach:
// HOT = raw bytes, WARM/COLD = length-truncated "compressed" payload as a
// placeholder for the real dictionary/bit-packing/delta+zstd pipeline.
// Swap this out for the real encoder when integrating into the DuckDB
// extension proper — the state machine and copy-on-write mechanism don't
// depend on which encoder is plugged in.
inline std::vector<uint8_t> PlaceholderEncode(const std::vector<uint8_t>& raw,
                                               PageState state) {
  if (state == PageState::HOT) return raw;
  // placeholder "compression": keep every 2nd (WARM) or 4th (COLD) byte,
  // just enough to make transitions produce visibly different payload
  // sizes for testing purposes. Not a real codec.
  size_t stride = (state == PageState::WARM) ? 2 : 4;
  std::vector<uint8_t> out;
  out.reserve(raw.size() / stride + 1);
  for (size_t i = 0; i < raw.size(); i += stride) out.push_back(raw[i]);
  return out;
}

class TemperatureTrackedPage {
 public:
  TemperatureTrackedPage(std::vector<uint8_t> raw_bytes, TemperatureConfig cfg)
      : raw_(std::move(raw_bytes)),
        cfg_(cfg),
        state_(PageState::HOT),
        temperature_(cfg.write_weight),
        below_threshold_streak_(0),
        page_(raw_) {}

  void OnWrite() {
    std::lock_guard<std::mutex> lock(bookkeeping_mutex_);
    temperature_ += cfg_.write_weight;
    below_threshold_streak_ = 0;
    if (state_ != PageState::HOT) {
      page_.Transcode(PageState::HOT, raw_, PlaceholderEncode);
      state_ = PageState::HOT;
    }
  }

  // NOTE: this records read-driven temperature pressure and is safe to
  // call from multiple concurrent reader threads (protected by
  // bookkeeping_mutex_). It does NOT gate access to the page itself —
  // Snapshot() below remains fully lock-free with respect to this call,
  // which is the actual property under test.
  void OnRead() {
    std::lock_guard<std::mutex> lock(bookkeeping_mutex_);
    temperature_ += cfg_.read_weight;
  }

  // Advance one tick: decay, evaluate demotion under hysteresis. Safe to
  // call from a background thread concurrently with readers calling
  // Snapshot() on page_ — that is exactly the scenario under test.
  void Tick() {
    std::lock_guard<std::mutex> lock(bookkeeping_mutex_);
    temperature_ *= cfg_.decay;
    if (temperature_ < cfg_.demote_threshold) {
      below_threshold_streak_++;
    } else {
      below_threshold_streak_ = 0;
    }

    if (below_threshold_streak_ >= cfg_.hysteresis_ticks) {
      if (state_ == PageState::HOT) {
        page_.Transcode(PageState::WARM, raw_, PlaceholderEncode);
        state_ = PageState::WARM;
      } else if (state_ == PageState::WARM) {
        page_.Transcode(PageState::COLD, raw_, PlaceholderEncode);
        state_ = PageState::COLD;
      }
      below_threshold_streak_ = 0;
    }
  }

  // Lock-free: never touches bookkeeping_mutex_. This is the call path
  // that matters for query performance, and it is independent of
  // however contended the temperature bookkeeping above gets.
  MorphingPage& Page() { return page_; }
  PageState State() const {
    std::lock_guard<std::mutex> lock(bookkeeping_mutex_);
    return state_;
  }

 private:
  std::vector<uint8_t> raw_;
  TemperatureConfig cfg_;
  PageState state_;
  double temperature_;
  int below_threshold_streak_;
  mutable std::mutex bookkeeping_mutex_;
  MorphingPage page_;
};

}  // namespace morphing_pages
