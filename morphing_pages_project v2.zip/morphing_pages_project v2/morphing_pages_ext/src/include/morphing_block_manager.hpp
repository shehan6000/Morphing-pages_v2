// morphing_block_manager.hpp
//
// Path B implementation, per DUCKDB_INTEGRATION_DESIGN.md: a BlockManager
// that intercepts DuckDB's block read/write path to apply temperature-
// driven encoding transitions, reusing morphing_page.hpp's already
// concurrency-tested copy-on-write mechanism (§4.7 of the paper).
//
// DESIGN: this is a DECORATOR, not a from-scratch BlockManager. It wraps
// an existing BlockManager (in practice, DuckDB's SingleFileBlockManager)
// and delegates block allocation, free-list tracking, and file-header
// management entirely to the wrapped instance — reimplementing that
// machinery would duplicate real, already-correct DuckDB code for no
// benefit. What THIS class owns is exactly one thing: intercepting the
// persist/read path for blocks that belong to registered "morphing"
// segments, so temperature tracking and Transcode() calls happen at the
// right point without touching block accounting at all.
//
// VERIFICATION STATUS: `ConvertToPersistent(block_id_t, shared_ptr<
// BlockHandle>, BufferHandle)` is confirmed against DuckDB's actual
// source (cross-referenced via a real crash report citing
// block_manager.cpp:58/79 and column_segment.cpp:246 — i.e. this
// signature and call chain are real, not guessed). Other method names
// below (CreateBlock, Read, GetBlockHandle, etc.) reflect BlockManager's
// documented "put/get interface for accessing files as a set of
// blocks" but their EXACT signatures are not independently verified —
// check against src/include/duckdb/storage/block_manager.hpp in a real
// checkout before compiling this for real. This file will NOT compile
// without the duckdb submodule; it is a integration starting point, not
// a tested artifact (unlike morphing_page.hpp, which is both).
#pragma once

// #include "duckdb/storage/block_manager.hpp"  // uncomment once submodule exists
#include <mutex>
#include <memory>
#include <unordered_map>

#include "morphing_page.hpp"
#include "temperature.hpp"

namespace duckdb {
// Forward declarations standing in for real DuckDB types until the
// submodule is available — remove once the real headers are included.
class BlockManager;
class BlockHandle;
class BufferHandle;
using block_id_t = int64_t;
}  // namespace duckdb

namespace morphing_pages {

// One instance per column segment that has opted into temperature-driven
// morphing (not every block needs to — plain metadata blocks, the file
// header, etc. should keep using the wrapped manager directly).
struct MorphingSegmentEntry {
  TemperatureTrackedPage tracked_page;
  duckdb::block_id_t underlying_block_id;

  MorphingSegmentEntry(std::vector<uint8_t> raw, TemperatureConfig cfg,
                        duckdb::block_id_t id)
      : tracked_page(std::move(raw), cfg), underlying_block_id(id) {}
};

class MorphingBlockManager /* : public duckdb::BlockManager */ {
 public:
  explicit MorphingBlockManager(duckdb::BlockManager &wrapped,
                                 TemperatureConfig cfg)
      : wrapped_(wrapped), default_cfg_(cfg) {}

  // --- Registration path: called when a ColumnSegment opts into
  // morphing (this hook point itself is still open — see
  // DUCKDB_INTEGRATION_DESIGN.md §2 on the checkpoint-timing problem;
  // the natural place to call this is wherever DuckDB currently calls
  // ConvertToPersistent for a segment we've decided to manage).
  void RegisterMorphingSegment(duckdb::block_id_t block_id,
                                std::vector<uint8_t> initial_raw_data) {
    std::lock_guard<std::mutex> lock(registry_mutex_);
    segments_[block_id] = std::make_unique<MorphingSegmentEntry>(
        std::move(initial_raw_data), default_cfg_, block_id);
  }

  // --- Read path: readers of a morphing-managed block get routed
  // through MorphingPage::Snapshot() (lock-free, concurrency-tested)
  // instead of the wrapped manager's normal block read. Everything
  // else falls through to the wrapped manager unchanged.
  //
  // Real signature TBD against BlockManager's actual Read()/ReadBlock()
  // interface — this shows the INTENT (route morphing blocks through
  // MorphingPage, delegate everything else), not a final signature.
  std::shared_ptr<const EncodedPage> ReadMorphingBlock(duckdb::block_id_t block_id) {
    std::lock_guard<std::mutex> lock(registry_mutex_);
    auto it = segments_.find(block_id);
    if (it == segments_.end()) {
      return nullptr;  // not a morphing-managed block; caller should
                        // fall back to wrapped_.Read(block_id) instead
    }
    // NOTE: recording the read for temperature purposes and returning
    // the snapshot are two separate concerns done here for brevity;
    // in the real implementation OnRead() should NOT be called while
    // holding registry_mutex_, since it takes its own internal lock
    // (bookkeeping_mutex_ in temperature.hpp) — avoid the nested-lock
    // pattern shown here once this is real code, to keep the
    // concurrency properties validated in §4.7 intact.
    it->second->tracked_page.OnRead();
    return it->second->tracked_page.Page().Snapshot();
  }

  // --- Write path: DuckDB's actual write path (INSERT/UPDATE landing
  // via LocalStorage -> DataTable -> ColumnData -> ColumnSegment,
  // eventually reaching ConvertToPersistent) needs to call this for
  // morphing-managed blocks instead of, or in addition to, the normal
  // persist path. Exact hook point is the open question flagged in
  // DUCKDB_INTEGRATION_DESIGN.md — this method exists to show WHERE
  // the write notification should land once that's resolved, not to
  // claim the hook point itself is solved.
  void OnMorphingBlockWritten(duckdb::block_id_t block_id) {
    std::lock_guard<std::mutex> lock(registry_mutex_);
    auto it = segments_.find(block_id);
    if (it != segments_.end()) {
      it->second->tracked_page.OnWrite();
    }
  }

  // --- Background morph driver: intended to be called periodically by
  // whatever DuckDB scheduling hook DUCKDB_INTEGRATION_DESIGN.md §2
  // resolves this to (a background task, or driven off checkpoint
  // scheduling) — NOT a fixed wall-clock tick like the standalone
  // prototype used, since DuckDB's own compression timing is
  // checkpoint-driven, not continuous.
  void TickAllMorphingSegments() {
    std::lock_guard<std::mutex> lock(registry_mutex_);
    for (auto &[block_id, entry] : segments_) {
      entry->tracked_page.Tick();
    }
  }

  // Everything not related to morphing-managed blocks delegates
  // straight through — this class does not reimplement block
  // allocation, free-list tracking, or file-header management.
  duckdb::BlockManager &Wrapped() { return wrapped_; }

 private:
  duckdb::BlockManager &wrapped_;
  TemperatureConfig default_cfg_;
  std::mutex registry_mutex_;
  std::unordered_map<duckdb::block_id_t, std::unique_ptr<MorphingSegmentEntry>>
      segments_;  // unique_ptr, NOT by-value: TemperatureTrackedPage holds a
                  // std::mutex internally (see temperature.hpp), which is
                  // neither copyable nor movable, so the entry can't live
                  // by-value inside the map. This was caught by a real
                  // compile error during development, not anticipated in
                  // advance — the same class of "shared mutable state
                  // needs explicit ownership design" issue that TSan
                  // caught at runtime in §4.7, this time caught by the
                  // type system instead.
};

}  // namespace morphing_pages
