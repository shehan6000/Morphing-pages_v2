// morphing_page.hpp
//
// The real systems contribution from §3.3 of the paper: a lock-free-for-
// readers, copy-on-write page transcoding mechanism. This header has no
// DuckDB dependency — it is a standalone, unit-testable component meant
// to be dropped into the DuckDB extension's storage layer (see
// src/morphing_pages_extension.cpp for the integration stub).
//
// Design invariant under test: a reader that acquires a snapshot of the
// page via Snapshot() must NEVER observe a partially-transcoded page,
// even while a background morph thread is concurrently building and
// installing a new encoding. This is verified under ThreadSanitizer in
// tests/concurrency_test.cpp, not just asserted here.
#pragma once

#include <atomic>
#include <cstdint>
#include <cstring>
#include <memory>
#include <vector>

namespace morphing_pages {

enum class PageState : uint8_t { HOT = 0, WARM = 1, COLD = 2 };

// A canary value written at both ends of the payload buffer. A reader
// that ever observes a corrupted canary has witnessed a torn page —
// this is the correctness oracle the concurrency test checks for on
// every read, not just a sanity check at construction time.
constexpr uint64_t kCanary = 0xDEADC0DEDEADC0DEULL;

struct EncodedPage {
  PageState state;
  std::vector<uint8_t> payload;  // canary-framed: [canary][data...][canary]
  uint64_t generation;           // monotonically increasing, for diagnostics

  explicit EncodedPage(PageState s, std::vector<uint8_t> data, uint64_t gen)
      : state(s), generation(gen) {
    payload.resize(data.size() + 2 * sizeof(kCanary));
    std::memcpy(payload.data(), &kCanary, sizeof(kCanary));
    std::memcpy(payload.data() + sizeof(kCanary), data.data(), data.size());
    std::memcpy(payload.data() + sizeof(kCanary) + data.size(), &kCanary,
                sizeof(kCanary));
  }

  // Returns false if either canary is corrupted — i.e. this snapshot was
  // torn during a concurrent write. A correct implementation must never
  // let a reader observe this.
  bool IsIntact() const {
    if (payload.size() < 2 * sizeof(kCanary)) return false;
    uint64_t front, back;
    std::memcpy(&front, payload.data(), sizeof(kCanary));
    std::memcpy(&back, payload.data() + payload.size() - sizeof(kCanary),
                sizeof(kCanary));
    return front == kCanary && back == kCanary;
  }
};

// MorphingPage: the atomic, copy-on-write handle around a page's current
// encoding. Exactly one field of mutable shared state: `current_`, an
// atomic<shared_ptr<const EncodedPage>>. All state transitions build a
// brand-new EncodedPage off to the side and then atomically swap the
// pointer — readers that already hold a Snapshot() keep the old object
// alive via shared_ptr refcounting until they're done with it, and never
// see a half-built page.
class MorphingPage {
 public:
  explicit MorphingPage(std::vector<uint8_t> initial_data)
      : generation_(0) {
    auto initial = std::make_shared<const EncodedPage>(
        PageState::HOT, std::move(initial_data), generation_.fetch_add(1));
    current_.store(initial, std::memory_order_release);
  }

  // Reader path: wait-free with respect to concurrent Transcode() calls.
  // Returns a shared_ptr keeping the snapshot alive for as long as the
  // caller needs it, regardless of how many transcodes happen afterward.
  std::shared_ptr<const EncodedPage> Snapshot() const {
    return current_.load(std::memory_order_acquire);
  }

  // Writer/morph path: builds the new encoding OFF the live page (never
  // mutates payload_ in place), then does a single atomic pointer swap.
  // `encode_fn` takes the *original* raw bytes and the target state and
  // returns the newly-encoded payload — this is where the real
  // dictionary/bit-packing/delta+compression pipeline from §3.1 plugs in.
  template <typename EncodeFn>
  void Transcode(PageState new_state, const std::vector<uint8_t>& raw_bytes,
                 EncodeFn&& encode_fn) {
    std::vector<uint8_t> new_payload = encode_fn(raw_bytes, new_state);
    auto new_page = std::make_shared<const EncodedPage>(
        new_state, std::move(new_payload), generation_.fetch_add(1));
    // The atomic swap itself: this is the entire critical section. No
    // lock is held while encode_fn ran above, so readers are never
    // blocked by (potentially slow) transcoding work.
    current_.store(new_page, std::memory_order_release);
  }

  PageState CurrentState() const {
    return current_.load(std::memory_order_acquire)->state;
  }

 private:
  std::atomic<std::shared_ptr<const EncodedPage>> current_;
  std::atomic<uint64_t> generation_;
};

}  // namespace morphing_pages
