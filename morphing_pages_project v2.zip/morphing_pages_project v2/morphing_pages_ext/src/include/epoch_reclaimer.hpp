// epoch_reclaimer.hpp
//
// The real concurrency hazard in a disk-backed copy-on-write scheme
// that morphing_page.hpp's pure in-memory version didn't have to solve:
// once a block is freed for reuse, ANOTHER thread could allocate that
// same block id and overwrite it while a reader is still mid-pread()
// against it, using a block id it fetched a moment earlier. That reader
// would silently get corrupted or mixed data — worse than a torn read,
// because the canary check in block_file.hpp can't catch "I read a
// block that now legitimately belongs to a different page."
//
// This is a small, fixed-slot epoch reclamation scheme (the same family
// of technique as RCU / hazard pointers, simplified for a bounded
// number of reader threads known up front): readers announce the
// current global epoch before touching a block id and clear their
// announcement after; the reclaimer only allows a freed block to be
// reused once every reader's announced epoch is past the epoch in
// which that block was freed.
#pragma once

#include <atomic>
#include <cstdint>
#include <limits>
#include <mutex>
#include <vector>

#include "block_file.hpp"

namespace morphing_pages {

constexpr uint64_t kNotReading = std::numeric_limits<uint64_t>::max();

class EpochReclaimer {
 public:
  explicit EpochReclaimer(int max_reader_threads)
      : reader_epochs_(max_reader_threads) {
    for (auto &e : reader_epochs_) e.store(kNotReading);
  }

  // Call before reading a block. Returns an RAII guard; while it's
  // alive, the reclaimer will not permit reuse of any block freed at
  // or after the epoch this call observed.
  class ReadGuard {
   public:
    ReadGuard(std::atomic<uint64_t> *slot, uint64_t epoch) : slot_(slot) {
      slot_->store(epoch, std::memory_order_release);
    }
    ~ReadGuard() { slot_->store(kNotReading, std::memory_order_release); }
    ReadGuard(const ReadGuard &) = delete;

   private:
    std::atomic<uint64_t> *slot_;
  };

  // reader_slot must be a stable index in [0, max_reader_threads) unique
  // to the calling thread for the test's lifetime — a real integration
  // would assign these from a thread-registration path; the test harness
  // assigns them directly since the thread count is fixed and known.
  ReadGuard BeginRead(int reader_slot) {
    uint64_t epoch = global_epoch_.load(std::memory_order_acquire);
    return ReadGuard(&reader_epochs_[reader_slot], epoch);
  }

  // Called by the writer/morph thread when it frees a block. Records
  // the epoch at which it was freed and bumps the global epoch so
  // subsequent readers observe a later epoch than this free.
  void RecordFree(block_id_t id) {
    std::lock_guard<std::mutex> lock(pending_mutex_);
    uint64_t freed_at = global_epoch_.fetch_add(1, std::memory_order_acq_rel);
    pending_.push_back({id, freed_at});
  }

  // Returns block ids that are now safe to hand back to
  // FileBlockManager::Free() — every reader's announced epoch is either
  // kNotReading or strictly greater than the epoch the block was freed
  // at. Call this periodically (the test calls it every reclaim pass).
  std::vector<block_id_t> ReclaimSafe() {
    uint64_t min_active = kNotReading;
    for (auto &slot : reader_epochs_) {
      uint64_t e = slot.load(std::memory_order_acquire);
      if (e < min_active) min_active = e;
    }

    std::lock_guard<std::mutex> lock(pending_mutex_);
    std::vector<block_id_t> safe;
    std::vector<PendingFree> still_pending;
    for (auto &pf : pending_) {
      if (min_active == kNotReading || pf.freed_at < min_active) {
        safe.push_back(pf.block_id);
      } else {
        still_pending.push_back(pf);
      }
    }
    pending_ = std::move(still_pending);
    return safe;
  }

  size_t PendingCount() const {
    std::lock_guard<std::mutex> lock(pending_mutex_);
    return pending_.size();
  }

 private:
  struct PendingFree {
    block_id_t block_id;
    uint64_t freed_at;
  };

  std::atomic<uint64_t> global_epoch_{0};
  std::vector<std::atomic<uint64_t>> reader_epochs_;
  mutable std::mutex pending_mutex_;
  std::vector<PendingFree> pending_;
};

}  // namespace morphing_pages
