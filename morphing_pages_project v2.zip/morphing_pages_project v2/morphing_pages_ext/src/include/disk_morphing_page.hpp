// disk_morphing_page.hpp
//
// Real, disk-backed version of the copy-on-write mechanism validated
// in-memory in morphing_page.hpp (§4.7 of the paper). The atomic swap
// target here is a block_id_t (trivially lock-free — no atomic<shared_ptr>
// needed at this layer) pointing into a real FileBlockManager, with
// EpochReclaimer guaranteeing a freed block is never reused while a
// reader might still be mid-pread() against it.
//
// This is the piece that closes the "never touched real persistent
// storage" gap without depending on DuckDB: it's a smaller, self-built
// storage engine, but every read and write below is a real syscall
// against a real file, not a simulation and not a stub.
#pragma once

#include <atomic>
#include <cstring>
#include <vector>

#include "block_file.hpp"
#include "epoch_reclaimer.hpp"

namespace morphing_pages {

enum class DiskPageState : uint8_t { HOT = 0, WARM = 1, COLD = 2 };

constexpr uint64_t kDiskCanary = 0xC0FFEEC0FFEEULL;

// Same canary-framing idea as EncodedPage in morphing_page.hpp, but
// serialized to/from real bytes on disk instead of an in-memory struct.
inline std::vector<uint8_t> EncodeWithCanary(const std::vector<uint8_t> &raw,
                                              DiskPageState state) {
  size_t stride = (state == DiskPageState::HOT) ? 1
                  : (state == DiskPageState::WARM) ? 2
                                                    : 4;
  std::vector<uint8_t> compressed;
  compressed.reserve(raw.size() / stride + 1);
  for (size_t i = 0; i < raw.size(); i += stride) compressed.push_back(raw[i]);

  std::vector<uint8_t> framed(sizeof(kDiskCanary) * 2 + compressed.size());
  std::memcpy(framed.data(), &kDiskCanary, sizeof(kDiskCanary));
  std::memcpy(framed.data() + sizeof(kDiskCanary), compressed.data(),
              compressed.size());
  std::memcpy(framed.data() + sizeof(kDiskCanary) + compressed.size(),
              &kDiskCanary, sizeof(kDiskCanary));
  return framed;
}

inline bool CheckCanary(const std::vector<uint8_t> &framed) {
  if (framed.size() < 2 * sizeof(kDiskCanary)) return false;
  uint64_t front, back;
  std::memcpy(&front, framed.data(), sizeof(kDiskCanary));
  std::memcpy(&back, framed.data() + framed.size() - sizeof(kDiskCanary),
              sizeof(kDiskCanary));
  return front == kDiskCanary && back == kDiskCanary;
}

class DiskMorphingPage {
 public:
  DiskMorphingPage(FileBlockManager &fbm, EpochReclaimer &reclaimer,
                    std::vector<uint8_t> raw_data)
      : fbm_(fbm), reclaimer_(reclaimer), raw_(std::move(raw_data)) {
    block_id_t id = fbm_.Allocate();
    fbm_.WriteBlock(id, EncodeWithCanary(raw_, DiskPageState::HOT));
    current_block_.store(id, std::memory_order_release);
    state_.store(DiskPageState::HOT, std::memory_order_release);
  }

  // Real read: pread the current block, verify canary. reader_slot
  // identifies this caller to the EpochReclaimer.
  bool Read(int reader_slot, std::vector<uint8_t> *out) const {
    auto guard = reclaimer_.BeginRead(reader_slot);
    block_id_t id = current_block_.load(std::memory_order_acquire);
    *out = fbm_.ReadBlock(id);
    return CheckCanary(*out);
  }

  // Real transcode: encode off to the side, allocate+write a NEW block,
  // atomically swap the pointer, THEN record the old block as pending
  // free (not immediately reusable — EpochReclaimer enforces that).
  void Transcode(DiskPageState new_state) {
    std::vector<uint8_t> encoded = EncodeWithCanary(raw_, new_state);
    block_id_t new_id = fbm_.Allocate();
    fbm_.WriteBlock(new_id, encoded);

    block_id_t old_id = current_block_.exchange(new_id, std::memory_order_acq_rel);
    state_.store(new_state, std::memory_order_release);
    reclaimer_.RecordFree(old_id);
  }

  DiskPageState State() const { return state_.load(std::memory_order_acquire); }

 private:
  FileBlockManager &fbm_;
  EpochReclaimer &reclaimer_;
  std::vector<uint8_t> raw_;
  std::atomic<block_id_t> current_block_{kInvalidBlock};
  std::atomic<DiskPageState> state_{DiskPageState::HOT};
};

}  // namespace morphing_pages
