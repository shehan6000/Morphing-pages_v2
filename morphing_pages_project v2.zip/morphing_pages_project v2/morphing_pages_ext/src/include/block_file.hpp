// block_file.hpp
//
// A genuinely real, from-scratch block manager: fixed-size blocks in an
// actual backing file on disk, allocated/freed/read/written via real
// pread(2)/pwrite(2). No DuckDB dependency, no stub types — this either
// works against a real file or it doesn't.
//
// This exists specifically to replace the DuckDB dependency that was
// blocking end-to-end validation: it is a smaller, self-built storage
// engine, not a claim to have built DuckDB's storage engine. The paper
// must be explicit about that distinction (see §4.8 in the updated
// draft) — this validates "the mechanism works against real persistent
// storage under real concurrency," not "the mechanism works inside
// DuckDB."
#pragma once

#include <cstdint>
#include <cstdio>
#include <cstring>
#include <mutex>
#include <stdexcept>
#include <string>
#include <unordered_set>
#include <vector>

#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>

namespace morphing_pages {

using block_id_t = int64_t;
constexpr block_id_t kInvalidBlock = -1;

class FileBlockManager {
 public:
  FileBlockManager(const std::string &path, size_t block_size)
      : block_size_(block_size) {
    fd_ = ::open(path.c_str(), O_RDWR | O_CREAT | O_TRUNC, 0644);
    if (fd_ < 0) {
      throw std::runtime_error("FileBlockManager: failed to open " + path);
    }
  }

  ~FileBlockManager() {
    if (fd_ >= 0) ::close(fd_);
  }

  FileBlockManager(const FileBlockManager &) = delete;
  FileBlockManager &operator=(const FileBlockManager &) = delete;

  // Allocates a block: reuses a freed block id if the free list is
  // non-empty, otherwise extends the file. Real disk space, real
  // ftruncate-equivalent growth via pwrite past EOF.
  block_id_t Allocate() {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!free_list_.empty()) {
      block_id_t id = free_list_.back();
      free_list_.pop_back();
      return id;
    }
    return next_block_id_++;
  }

  // Marks a block id as free for reuse. Caller is responsible for
  // ensuring no reader can still be accessing it (see EpochReclaimer in
  // epoch_reclaimer.hpp) — this class does NOT do that safety check
  // itself, deliberately: block allocation and reclamation safety are
  // different concerns, and conflating them here would hide exactly the
  // bug class (unsafe reuse of live memory/storage) this whole test
  // exists to catch.
  void Free(block_id_t id) {
    std::lock_guard<std::mutex> lock(mutex_);
    free_list_.push_back(id);
  }

  // Real pwrite. Pads to block_size_ if data is shorter; throws if
  // data is larger than a block (real constraint, not simulated).
  void WriteBlock(block_id_t id, const std::vector<uint8_t> &data) {
    if (data.size() > block_size_) {
      throw std::runtime_error("FileBlockManager: payload exceeds block size");
    }
    std::vector<uint8_t> padded(block_size_, 0);
    std::memcpy(padded.data(), data.data(), data.size());
    off_t offset = static_cast<off_t>(id) * static_cast<off_t>(block_size_);
    ssize_t written = ::pwrite(fd_, padded.data(), block_size_, offset);
    if (written != static_cast<ssize_t>(block_size_)) {
      throw std::runtime_error("FileBlockManager: short/failed write");
    }
  }

  // Real pread.
  std::vector<uint8_t> ReadBlock(block_id_t id) const {
    std::vector<uint8_t> buf(block_size_);
    off_t offset = static_cast<off_t>(id) * static_cast<off_t>(block_size_);
    ssize_t got = ::pread(fd_, buf.data(), block_size_, offset);
    if (got != static_cast<ssize_t>(block_size_)) {
      throw std::runtime_error("FileBlockManager: short/failed read");
    }
    return buf;
  }

  size_t BlockSize() const { return block_size_; }
  int64_t BlocksAllocated() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return next_block_id_;
  }

 private:
  int fd_ = -1;
  size_t block_size_;
  mutable std::mutex mutex_;
  block_id_t next_block_id_ = 0;
  std::vector<block_id_t> free_list_;
};

}  // namespace morphing_pages
