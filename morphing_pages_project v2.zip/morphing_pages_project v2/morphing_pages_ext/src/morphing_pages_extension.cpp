// morphing_pages_extension.cpp
//
// Extension entry-point STUB. This is intentionally not a working DuckDB
// extension yet — it shows the shape of where morphing_page.hpp and
// temperature.hpp plug into DuckDB's extension API, following the
// conventions of DuckDB's extension-template repo. Filling this in for
// real requires:
//
//   1. The duckdb/ submodule checked out (see BUILDING.md) so
//      "duckdb.hpp" and the DUCKDB_EXTENSION_ENTRYPOINT macros resolve.
//   2. Hooking into DuckDB's storage layer at the page/block level
//      (DuckDB's ColumnSegment / block manager) rather than exposing
//      this as a table function — the real integration point is lower
//      in the storage stack than the extension API's "add a SQL
//      function" surface that most example extensions demonstrate.
//      This is the open engineering question §5 of the paper flags,
//      not yet resolved even at the skeleton level.
//
// #include "duckdb.hpp"
#include "include/morphing_page.hpp"
#include "include/temperature.hpp"

namespace duckdb {

// Sketch of the intended integration surface. Real DuckDB storage hooks
// (compression function registration, or a custom TableStorageInfo) go
// here once the submodule is available — see the comment above.
class MorphingPagesExtension /* : public Extension */ {
 public:
  // static void Load(DuckDB &db);
  // static std::string Name() { return "morphing_pages"; }
};

}  // namespace duckdb

// extern "C" {
// DUCKDB_EXTENSION_API void morphing_pages_init(duckdb::DatabaseInstance &db) {
//   duckdb::MorphingPagesExtension::Load(db);
// }
// DUCKDB_EXTENSION_API const char *morphing_pages_version() {
//   return duckdb::DuckDB::LibraryVersion();
// }
// }
