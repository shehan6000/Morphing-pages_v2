// concurrency_test.cpp
//
// The actual evidence for §3.3's safety claim. Spins up concurrent
// reader threads, a writer thread, and a background morph thread against
// a single TemperatureTrackedPage, and checks two things on every read:
//
//   1. The snapshot's canary bytes are intact (IsIntact()) — i.e. no
//      reader ever observes a torn/partially-written page.
//   2. No data race is reported by ThreadSanitizer (build with
//      -fsanitize=thread; see run.sh).
//
// This does NOT test integration with a real DuckDB storage layer — it
// tests the copy-on-write mechanism itself, in isolation, under real
// concurrent load. That is a meaningfully stronger claim than the
// Python simulation could make (which was single-threaded), but it is
// still a unit-level test, not a full systems evaluation. Be precise
// about that distinction when citing this result in the paper.

#include <atomic>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <thread>
#include <vector>

#include "../src/include/temperature.hpp"

using namespace morphing_pages;

int main() {
  constexpr int kReaderThreads = 8;
  constexpr int kRunMillis = 2000;
  constexpr size_t kPageBytes = 8192;

  std::vector<uint8_t> initial(kPageBytes, 0x42);
  TemperatureConfig cfg;
  cfg.hysteresis_ticks = 1;  // force frequent transitions to stress-test harder
  TemperatureTrackedPage tracked(initial, cfg);

  std::atomic<bool> stop{false};
  std::atomic<uint64_t> reads_ok{0};
  std::atomic<uint64_t> reads_corrupt{0};
  std::atomic<uint64_t> writes_done{0};
  std::atomic<uint64_t> ticks_done{0};

  // Reader threads: continuously snapshot the page and verify the canary.
  std::vector<std::thread> readers;
  for (int i = 0; i < kReaderThreads; i++) {
    readers.emplace_back([&] {
      while (!stop.load(std::memory_order_relaxed)) {
        auto snap = tracked.Page().Snapshot();
        if (snap->IsIntact()) {
          reads_ok.fetch_add(1, std::memory_order_relaxed);
        } else {
          reads_corrupt.fetch_add(1, std::memory_order_relaxed);
        }
        tracked.OnRead();
      }
    });
  }

  // Writer thread: periodic writes, forcing promotion back to HOT.
  std::thread writer([&] {
    while (!stop.load(std::memory_order_relaxed)) {
      tracked.OnWrite();
      writes_done.fetch_add(1, std::memory_order_relaxed);
      std::this_thread::sleep_for(std::chrono::milliseconds(7));
    }
  });

  // Morph thread: the background daemon from §3.3, driving Tick() (and
  // therefore Transcode()) concurrently with the readers above.
  std::thread morpher([&] {
    while (!stop.load(std::memory_order_relaxed)) {
      tracked.Tick();
      ticks_done.fetch_add(1, std::memory_order_relaxed);
      std::this_thread::sleep_for(std::chrono::milliseconds(3));
    }
  });

  std::this_thread::sleep_for(std::chrono::milliseconds(kRunMillis));
  stop.store(true, std::memory_order_relaxed);

  for (auto& t : readers) t.join();
  writer.join();
  morpher.join();

  std::printf("=== Morphing Pages concurrency test ===\n");
  std::printf("reads_ok       = %llu\n", (unsigned long long)reads_ok.load());
  std::printf("reads_corrupt  = %llu\n", (unsigned long long)reads_corrupt.load());
  std::printf("writes_done    = %llu\n", (unsigned long long)writes_done.load());
  std::printf("ticks_done     = %llu\n", (unsigned long long)ticks_done.load());
  std::printf("final_state    = %d\n", (int)tracked.State());

  if (reads_corrupt.load() > 0) {
    std::printf("FAIL: %llu torn/corrupt page(s) observed by readers\n",
                (unsigned long long)reads_corrupt.load());
    return 1;
  }
  std::printf("PASS: zero torn pages observed across %llu reads under "
              "concurrent writes/morphs\n",
              (unsigned long long)reads_ok.load());
  return 0;
}
