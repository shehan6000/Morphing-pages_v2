#!/usr/bin/env bash
# Runs the concurrency test twice: once as a plain release build (fast,
# high iteration count), once under ThreadSanitizer (slower, but the
# build that actually caught a real bug during development). See
# BUILDING.md for details on what each does and doesn't validate.
set -e
cd "$(dirname "$0")/.."

mkdir -p build

echo "=== Release build ==="
g++ -std=c++20 -O2 -pthread tests/concurrency_test.cpp -o build/concurrency_test_release
./build/concurrency_test_release

echo ""
echo "=== ThreadSanitizer build ==="
g++ -std=c++20 -O1 -g -fsanitize=thread -pthread tests/concurrency_test.cpp -o build/concurrency_test_tsan
TSAN_OPTIONS="halt_on_error=0" ./build/concurrency_test_tsan
