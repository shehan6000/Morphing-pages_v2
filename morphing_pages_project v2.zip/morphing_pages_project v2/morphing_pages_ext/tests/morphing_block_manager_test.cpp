// morphing_block_manager_test.cpp
//
// Exercises MorphingBlockManager against the stub duckdb:: types
// declared in morphing_block_manager.hpp (NOT real DuckDB — those
// forward declarations are placeholders). This cannot validate real
// DuckDB integration; it exists to catch structural bugs in the
// decorator itself (ownership, locking, delegation) before they're
// discovered inside a real, much slower DuckDB build/test cycle. The
// unique_ptr storage fix in this file's sibling header was caught
// exactly this way — by trying to compile something that exercises the
// class, not by inspection.
#include <cassert>
#include <cstdio>
#include <thread>
#include <vector>

#include "../src/include/morphing_block_manager.hpp"

using namespace morphing_pages;

int main() {
  // Stand-in for a real duckdb::BlockManager& — we never call methods
  // on it in this test (MorphingBlockManager only stores the
  // reference), so an incomplete forward-declared type is sufficient
  // here, same as in the header itself.
  struct FakeWrappedManager {};
  FakeWrappedManager fake_wrapped;
  auto &wrapped_ref = reinterpret_cast<duckdb::BlockManager &>(fake_wrapped);

  TemperatureConfig cfg;
  MorphingBlockManager mgr(wrapped_ref, cfg);

  std::vector<uint8_t> initial(4096, 0x7A);
  mgr.RegisterMorphingSegment(/*block_id=*/1, initial);

  // A read on a registered block should return a real snapshot.
  auto snap = mgr.ReadMorphingBlock(1);
  assert(snap != nullptr);
  assert(snap->IsIntact());
  printf("PASS: registered block returns intact snapshot\n");

  // A read on an unregistered block should return nullptr (fall-through
  // signal to the caller), not crash.
  auto missing = mgr.ReadMorphingBlock(999);
  assert(missing == nullptr);
  printf("PASS: unregistered block returns nullptr (fall-through)\n");

  // Write + tick should not crash and should route to the right entry.
  mgr.OnMorphingBlockWritten(1);
  mgr.TickAllMorphingSegments();
  printf("PASS: write/tick on registered block completes without error\n");

  // Concurrent registration + read from multiple threads should not
  // crash or deadlock (the property that mattered in §4.7, exercised
  // here at the decorator level rather than the raw MorphingPage level).
  std::vector<std::thread> threads;
  for (int i = 0; i < 4; i++) {
    threads.emplace_back([&mgr, i] {
      std::vector<uint8_t> data(256, static_cast<uint8_t>(i));
      mgr.RegisterMorphingSegment(100 + i, data);
      for (int j = 0; j < 1000; j++) {
        auto s = mgr.ReadMorphingBlock(100 + i);
        if (s) assert(s->IsIntact());
      }
    });
  }
  for (auto &t : threads) t.join();
  printf("PASS: concurrent registration + reads across 4 threads, no crash\n");

  printf("\nAll MorphingBlockManager structural tests passed.\n");
  printf("NOTE: this validates decorator structure only, against stub\n");
  printf("duckdb:: types -- it does NOT validate real DuckDB integration.\n");
  return 0;
}
