# DuckDB Integration Design

This resolves the open question flagged in `morphing_pages_extension.cpp`:
exactly where does the copy-on-write mechanism (`morphing_page.hpp`,
concurrency-validated in §4.7 of the paper) plug into DuckDB's actual
storage architecture. Verified against DuckDB's current internals
(DeepWiki/Factory AutoWiki documentation, cross-checked against the
compression-function interface and storage engine overview) rather than
assumed — this matters because getting the integration point wrong
means redoing real engineering work, not just a design doc.

## What DuckDB's storage stack actually looks like

```
INSERT/UPDATE/DELETE
  -> LocalStorage (transaction-local, uncommitted)
  -> on commit: DataTable
  -> DataTable -> RowGroup -> ColumnData -> ColumnSegment
  -> ColumnSegment allocates blocks via BlockManager
  -> BlockManager reads/writes via BufferManager
  -> BufferManager pins/unpins against the single database file
```

Relevant facts that change the integration plan:

1. **Fixed 256KB blocks.** The database file is divided into fixed-size
   256KB blocks, set at database-creation time. A column segment may
   span multiple blocks. "Page" in the paper's current framing (a few
   thousand rows) does not map 1:1 onto a DuckDB block — this needs to
   be resolved explicitly (see "Granularity mismatch" below), not left
   implicit, because a reviewer will ask what a "page" is in DuckDB
   terms.

2. **Compression is selected once, at checkpoint time, not continuously.**
   Every `CompressionFunction` implements `InitAnalyze` / `Analyze` /
   `FinalAnalyze` / `InitCompression` / `Compress` / `FinalizeCompress`.
   The `Analyze` phase runs during checkpointing and picks the best
   scheme (RLE, dictionary, FSST, bitpacking, ZSTD, etc.) from
   statistics gathered at that moment. This is a **write-time decision**,
   not something DuckDB re-evaluates later based on subsequent read
   access — which is exactly the gap Morphing Pages is trying to close,
   but it also means we can't simply "hook into" the existing
   compression-function analyze step and expect it to fire again later
   when a page goes cold. Something has to force re-evaluation.

3. **`BlockManager` is confirmed subclassable and is a narrow,
   documented interface** (`src/include/duckdb/storage/block_manager.hpp`),
   explicitly called out as the extension point for "an alternative
   block manager (e.g., for an embedded environment)." This sits
   *below* the compression-function layer — a custom `BlockManager`
   owns raw block read/write and can apply its own encoding scheme
   transparently, independent of DuckDB's own segment analyze/compress
   cycle.

## Three integration paths, honestly compared

### Path A — Custom `CompressionFunction`, forced re-checkpoint

Register a "morphing" compression function whose `Analyze` phase
consults a side-table of per-segment temperature metadata (updated on
scan/append) to choose among the three sub-encodings, then periodically
force cold segments to be re-checkpointed so `Analyze`/`Compress` run
again with updated temperature data.

**Problem, stated plainly**: DuckDB's checkpoint only rewrites *dirty*
segments. A segment that's gone cold — no new writes, only reads —
is not dirty, so a normal checkpoint won't touch it, and there is no
first-class "recompress this segment in place" API to force the
issue. Achieving this would require either an undocumented internal
hook (real risk: doesn't exist, or exists but isn't extension-stable
across DuckDB versions) or a rewrite-based workaround that makes this
path converge with Path C below anyway. **This path looked promising
before checking DuckDB's checkpoint semantics; after checking, it's
the weakest of the three.**

### Path B — Custom `BlockManager` (recommended primary path)

Implement a `BlockManager` subclass that owns raw block I/O and applies
`morphing_page.hpp`'s copy-on-write logic directly at the block level,
entirely independent of DuckDB's compression-function/checkpoint cycle.
DuckDB calls into this BlockManager for all reads/writes; temperature
tracking hooks into the same read/write calls.

**Why this is the better path**: it sidesteps the write-time-only
compression decision problem in Path A entirely — we own the
encode/decode logic ourselves (which `morphing_page.hpp` and
`temperature.hpp` already implement and concurrency-test), so there's
no fight with DuckDB's own checkpoint semantics.

**Real cost, stated plainly**: we give up DuckDB's existing compression
algorithm library (dictionary, FSST, bitpacking, etc.) and must own the
full encode/decode path ourselves — which is already the plan (§3.1's
three-state spectrum), so this isn't new work, but it does mean this
path can't casually borrow DuckDB's compression internals as a
shortcut.

**Granularity mismatch, to resolve explicitly**: a DuckDB block is
256KB. Our prototype's "page" (§4) is ~8KB (1024 float64 values). A
custom BlockManager most naturally operates at the 256KB block
granularity, not our prototype's finer granularity. Two honest options:
(a) redefine "page" in the paper to mean a 256KB DuckDB block, and
re-run the §4 evaluation at that page size before claiming the same
94.42%/24× numbers hold — they may not, since larger pages change the
compression-ratio and decode-latency-per-byte tradeoffs; or (b) manage
sub-block regions ourselves within a BlockManager-owned block, which
adds real complexity DuckDB doesn't have a native concept for. **(a) is
the honest, lower-risk choice** — it costs a re-run of §4.1–4.6 at the
new page size, not a research redesign.

### Path C — SQL-level maintenance job (guaranteed-buildable fallback)

No source modification at all: a background process using only
DuckDB's public SQL/C API tracks access patterns in a side table and
periodically rewrites cold partitions (`CREATE TABLE ... AS SELECT ...
WHERE <cold predicate>`, or `COPY` to a separately-compressed Parquet
file) while keeping hot data in the live table, unified via a view.

**Trade-off, stated plainly**: this is real, achievable today with the
public extension-template and zero internals risk, but it operates at
partition/table granularity, not page granularity — it is a materially
weaker version of the paper's contribution, closer to what TimescaleDB
already does (the thing we're trying to improve on) than to Morphing
Pages' actual claim. **This is the fallback if Path B proves
infeasible within the DaMoN timeline, not the target design** — citing
Path C results as validating the page-level claim would overclaim.

## Recommendation

Pursue **Path B**, with the granularity redefinition in (a) above
resolved *before* writing implementation code, not after — re-running
§4.1–4.6 at 256KB page size is cheap (the Python simulation already
supports arbitrary page sizes via `make_raw_page`'s `n_values`
parameter) and should happen first, so the DuckDB implementation is
built against numbers that actually hold at the real target
granularity. Keep Path C in reserve as an honest fallback for a
short-paper submission if Path B's BlockManager integration proves too
large a scope for the DaMoN timeline.

## Immediate next step

Before writing any `BlockManager` subclass code: re-run the Python
sensitivity sweep (`morphing_pages/sweep.py`) at `n_values=32768`
(≈256KB of float64 data, matching a DuckDB block) instead of the
current 1024, and confirm the §4.2 headline result (adaptive matches
fixed-schedule storage efficiency at meaningfully lower read latency)
still holds at that page size. If it doesn't hold, that's a finding
that changes the paper's claims before any C++ integration work starts
— cheaper to discover now than after building the BlockManager.
