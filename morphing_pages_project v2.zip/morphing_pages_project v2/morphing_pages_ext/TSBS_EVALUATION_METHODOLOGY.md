# TSBS Baseline Evaluation Methodology

Plan for replacing §4's simulated `fixed-schedule` baseline with real
TimescaleDB and InfluxDB installations, using the Time Series Benchmark
Suite (TSBS). This is design/methodology only — no TimescaleDB or
InfluxDB instance exists in this sandbox (would require Docker
containers this environment isn't set up to run), so nothing here has
been executed. Treat every number in this document as a target or a
placeholder, not a result.

## 1. Why TSBS specifically

TSBS (github.com/timescale/tsbs) is the standard benchmark for
time-series database comparison, purpose-built to generate the exact
ingest-then-analyze workload shape this paper's synthetic trace
(§4.1) was designed to approximate. Using it directly, instead of the
synthetic trace, closes the "simulated workload" objection alongside
the "simulated baseline" objection in the same step — both TimescaleDB
and InfluxDB have first-class TSBS support already, which is why they
were chosen as baselines in the first place rather than arbitrary
competitors.

## 2. Systems under test

| System | Role | Setup |
|---|---|---|
| DuckDB + Morphing Pages extension | The paper's contribution | Requires the Path B `BlockManager` integration from `DUCKDB_INTEGRATION_DESIGN.md` to exist first — this is the hard dependency that blocks running this methodology at all |
| TimescaleDB | Coarse-grained baseline (real system, not simulated) | Docker container, TSBS's built-in TimescaleDB loader, default compression policy settings matching what the paper's `FixedSchedulePolicy` approximates |
| InfluxDB | Second coarse-grained baseline | Docker container, TSBS's built-in InfluxDB (2.x, TSM engine) loader |
| Plain DuckDB, no extension | Sanity-check baseline | Confirms the extension's overhead vs. vanilla DuckDB on the same queries, isolating "cost of the mechanism" from "benefit of the mechanism" |

## 3. Workload configuration

TSBS ships several use-cases; the closest match to this paper's claims:

- **`cpu-only` or `devops` use case**: sensor/telemetry-style
  ingest-then-query pattern, matching §2's motivating example directly.
- **Scale factor**: start small (100 devices, TSBS default
  `--scale=100`) to validate the pipeline end-to-end before scaling up
  — this mirrors the paper's own page-count progression (200 → 20,000
  in §4.4) rather than jumping straight to a large scale factor.
- **Query mix**: TSBS's standard query types include high-selectivity
  point lookups (stresses the HOT path), time-range scans over recent
  data (stresses WARM), and full historical scans (stresses COLD) —
  this maps directly onto the three-state spectrum in §3.2, which is
  useful framing for the results section once real numbers exist.

## 4. Metrics to collect (mirroring §4's structure so results are comparable)

| §4 metric | TSBS equivalent |
|---|---|
| Avg. read latency (§4.2) | TSBS's reported query latency (p50/p99) per query type |
| Final storage (§4.2) | Database file size / `du` on the data directory after ingest + a settling period |
| Morph/compress CPU time (§4.2, §4.5) | `perf` or `/proc/<pid>/stat` CPU-time sampling on the DuckDB process during the settling period, isolating background compression work from query-serving threads |
| Thrash rate (§4.3) | Count of state transitions per segment, logged by the extension itself (already implemented as `EncodedPage.generation` in `morphing_page.hpp` — each transcode increments it, so this is close to free to expose) |

## 5. Honest sequencing — this cannot start yet

This methodology has a hard prerequisite that hasn't been met: **there
is no working DuckDB extension to benchmark**. Running TSBS today would
only produce TimescaleDB-vs-InfluxDB numbers, which doesn't test this
paper's contribution at all. The actual sequencing is:

1. `DUCKDB_INTEGRATION_DESIGN.md` Path B (custom `BlockManager`) gets
   built, in a real dev environment with the DuckDB submodule checked
   out — not here.
2. The granularity re-validation already done (§ this document's
   companion result: 256KB-page headline result holds, in fact
   strengthens) confirms the extension should target real DuckDB block
   size, not the paper's original 8KB test size — this avoids finding
   out post-hoc that the implementation was built at the wrong
   granularity.
3. Only once (1) produces a working, loadable extension does this TSBS
   methodology become executable rather than aspirational.

## 6. What to do differently from a naive TSBS run

A naive "just run TSBS against three systems" approach would produce
numbers that don't isolate the actual claim. Two adjustments:

- **Run the `fixed-schedule`-equivalent config on DuckDB itself, not
  just on TimescaleDB/InfluxDB.** I.e., configure the Morphing Pages
  extension in a "compress-on-fixed-schedule" mode (trivial: set
  `hysteresis_ticks` effectively infinite and force a schedule-based
  trigger) as an additional baseline. This isolates "DuckDB is
  generally faster than TimescaleDB/InfluxDB for unrelated reasons"
  from "adaptive morphing specifically beats fixed-schedule
  compression" — the paper's actual claim is the latter, and without
  this control, a DuckDB-wins-across-the-board result wouldn't
  distinguish the two.
- **Report the sanity-check baseline (plain DuckDB, no extension)
  even if it's the fastest of all.** If vanilla DuckDB with no
  temperature-adaptive anything beats everything else, that is an
  important, reportable result about diminishing returns — not a
  result to bury because it complicates the narrative.
