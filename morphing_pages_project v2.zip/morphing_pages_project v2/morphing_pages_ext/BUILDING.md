# Building Morphing Pages

Two very different things live in this repo, and it's important to keep
them distinct when citing results in the paper.

## 1. The standalone concurrency test — builds and runs right now

No DuckDB dependency. Just C++20 + pthreads.

```bash
mkdir -p build && cd build
cmake .. -DCMAKE_BUILD_TYPE=Release
make concurrency_test
./concurrency_test
```

Or run the ThreadSanitizer build directly (recommended — it caught a
real bug during development that the release build's pass/fail check
alone did not surface):

```bash
g++ -std=c++20 -O1 -g -fsanitize=thread -pthread tests/concurrency_test.cpp -o build/concurrency_test_tsan
TSAN_OPTIONS="halt_on_error=0" ./build/concurrency_test_tsan
```

**What this validates**: the copy-on-write mechanism in
`src/include/morphing_page.hpp` (§3.3 of the paper) under real
concurrent reader/writer/morph threads — zero torn-page reads and zero
TSan-reported data races across ~15M release-build reads and ~478K
TSan-instrumented reads in the runs used for the paper.

**What this does NOT validate**: integration with a real DuckDB
storage layer, query concurrency at the engine level, or the
compression pipeline itself (the encoder in `temperature.hpp` is a
placeholder stand-in, not the real dictionary/bit-packing/delta+zstd
pipeline from §3.1 — swap it for the real one before citing storage
numbers from this repo, not just latency/correctness numbers).

## 2. The full DuckDB extension — not buildable in this repo yet

Following DuckDB's extension-template conventions:

```bash
git clone --recurse-submodules https://github.com/duckdb/duckdb.git third_party/duckdb
# copy this repo's CMakeLists.txt logic into an out-of-tree extension
# following https://github.com/duckdb/extension-template
make            # this is the expensive step: 20-30+ min, several GB
```

This is not run in this repo because building DuckDB from source is a
large, slow operation not suited to a quick iteration loop, and because
the actual integration point (hooking morphing_page.hpp into DuckDB's
storage/block layer, not its SQL-function extension surface) is still
an open design question — see the comment block at the top of
`src/morphing_pages_extension.cpp`. That's the real remaining
engineering work, not a build-script problem.
