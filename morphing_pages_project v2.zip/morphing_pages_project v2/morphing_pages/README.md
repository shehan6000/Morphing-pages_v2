# Morphing Pages

Prototype and benchmark harness for **temperature-adaptive columnar page
layout** — the systems contribution behind the DaMoN 2027 submission
(see `morphing-columnar-pages-gap-statement.md` for the research gap,
related-work framing, and submission strategy).

## What this is

A simulation-level prototype, not a DuckDB extension (yet). It models:

- A **3-state page encoding spectrum**: HOT (uncompressed) → WARM (light
  compression) → COLD (delta + heavy compression), implemented with real
  zlib compression on synthetic float64 column data — so the compression
  ratios and (de)compression latencies are real measurements, not made up.
- A **per-page temperature score** (exponentially decayed read/write
  activity) driving state transitions, with a **hysteresis guard** to
  prevent thrashing under bursty access.
- Two baselines to compare against: a naive **static-uncompressed**
  policy, and a **fixed-schedule** policy that mimics chunk/shard-level
  compression jobs (TimescaleDB-style) — compress once after N idle
  ticks, decompress fully on any write.

This is intentionally scoped to be fast to build and honest about what
it proves: it validates the *core claim* (page-level adaptive encoding
beats coarse-grained fixed-schedule compression on read latency, at
equal final storage) using a synthetic workload. It is **not** yet
integrated into a real storage engine — that's the next step (a DuckDB
storage extension) once these numbers hold up under a TSBS-based trace.

## Project layout

```
morphing_pages/
  encoding.py    # HOT/WARM/COLD encode+decode simulation (real zlib + delta transform)
  page.py        # Page: temperature tracking + hysteresis state machine (the core contribution)
  policies.py    # StaticPolicy and FixedSchedulePolicy baselines
  workload.py    # synthetic write-then-decay trace generator (TSBS-style ingest-then-analyze)
  benchmark.py   # replays a trace through all three policies, computes headline metrics
  main.py        # CLI: runs the benchmark, prints a summary table, saves JSON/CSV/PNG
```

## Running it

```bash
python3 -m morphing_pages.main
```

Outputs land in `results/`:
- `benchmark_summary.json` — headline metrics per policy
- `storage_footprint_timeseries.csv` — total encoded bytes per tick, per policy
- `storage_footprint.png` — the plot for the paper's evaluation section

## Current headline result (200 pages, 200 ticks, seed=42)

| policy | avg read latency (µs) | final storage (% of raw) | morph CPU time (s) |
|---|---|---|---|
| adaptive | 0.23 | 94.42 | 0.135 |
| static-uncompressed | 0.07 | 100.00 | 0.000 |
| fixed-schedule | 5.46 | 94.42 | 0.079 |

**The claim this supports**: adaptive page-level morphing reaches the
*same* final storage efficiency as coarse-grained fixed-schedule
compression, but with roughly 24× lower average read latency — because
it doesn't compress a page to COLD while it's still being actively
read. Static-uncompressed has the lowest read latency of all (no
decode cost) but pays for it with 100% storage — the adaptive policy is
the only one that gets close to fixed-schedule's storage efficiency
without fixed-schedule's read-latency penalty.

## Next steps toward the DaMoN 2027 submission

1. Replace the synthetic write-then-decay trace with a real TSBS-derived
   trace to strengthen the evaluation section.
2. Add TimescaleDB and InfluxDB as literal baselines (run the real
   systems, not simulated policies) if time allows — reviewers will
   trust measured numbers over simulated baselines more.
3. Port `page.py`'s state machine logic into an actual DuckDB storage/
   compression extension, so the copy-on-write transactional-safety
   claim in the gap statement is demonstrated, not just asserted.
4. Sweep `TemperatureConfig` (decay, thresholds, hysteresis_ticks) to
   report sensitivity — reviewers will ask whether the thresholds are
   overfit to this workload.
5. Add a CPU-overhead-vs-workload-size scaling experiment (does the
   background morphing daemon stay cheap at 10k+ pages?).
