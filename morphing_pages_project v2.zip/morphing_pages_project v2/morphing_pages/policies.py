"""
Baseline policies compared against the adaptive Page state machine.
"""
from .encoding import PageState, encode_page


class StaticPolicy:
    """Never compress: every page stays HOT (uncompressed). Represents the
    naive upper bound on read/write latency and lower bound on storage
    efficiency."""
    name = "static-uncompressed"

    def __init__(self, raw_bytes_by_page):
        self.raw = raw_bytes_by_page
        self.encoded = {}  # populated lazily, on first write, for fair comparison
        self.morph_cpu_time_s = 0.0

    def on_write(self, tick, page_id):
        if page_id not in self.encoded:
            self.encoded[page_id] = encode_page(self.raw[page_id], PageState.HOT)

    def on_read(self, tick, page_id):
        pass

    def tick(self, tick):
        pass


class FixedSchedulePolicy:
    """Mimics chunk/shard-level compression jobs (TimescaleDB-style):
    compress a page straight to COLD once it has gone `compress_after`
    ticks without a write, regardless of read pattern afterward. Any new
    write forces a full, immediate decompress back to HOT — this is the
    coarse-grained, schedule-triggered baseline the paper argues against.
    """
    name = "fixed-schedule"

    def __init__(self, raw_bytes_by_page, compress_after: int = 20):
        self.raw = raw_bytes_by_page
        self.compress_after = compress_after
        self.state = {}
        self.encoded = {}  # populated lazily, on first write
        self.last_write_tick = {}
        self.morph_cpu_time_s = 0.0

    def on_write(self, tick, page_id):
        self.last_write_tick[page_id] = tick
        if self.state.get(page_id) != PageState.HOT:
            enc = encode_page(self.raw[page_id], PageState.HOT)
            self.morph_cpu_time_s += enc.encode_time_s
            self.state[page_id] = PageState.HOT
            self.encoded[page_id] = enc

    def on_read(self, tick, page_id):
        pass

    def tick(self, tick):
        for p, last_write in self.last_write_tick.items():
            if self.state[p] == PageState.HOT and (tick - last_write) >= self.compress_after:
                enc = encode_page(self.raw[p], PageState.COLD)
                self.morph_cpu_time_s += enc.encode_time_s
                self.state[p] = PageState.COLD
                self.encoded[p] = enc
