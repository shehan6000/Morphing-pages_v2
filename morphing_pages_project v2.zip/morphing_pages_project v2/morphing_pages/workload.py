"""
Synthetic write-then-decay workload generator, standing in for TSBS-style
ingest-then-analyze access patterns: a page is written in a burst right
after creation, then read with decaying probability, then goes silent
(archived / fully cold).
"""
import random
import struct


def make_raw_page(n_values: int = 1024, seed: int = 0) -> bytes:
    rng = random.Random(seed)
    base = rng.uniform(10, 100)
    vals = [base + rng.gauss(0, 1.5) for _ in range(n_values)]
    return struct.pack(f"<{n_values}d", *vals)


def generate_trace(n_pages: int, n_ticks: int, write_burst_ticks: int = 5,
                    read_decay_ticks: int = 40, seed: int = 42):
    """
    Yields (tick, page_id, event) with event in {"write", "read"}.

    Lifecycle per page: created at a random tick -> short write burst ->
    decaying read pressure -> silence (goes cold and stays cold).
    """
    rng = random.Random(seed)
    page_created_at = {p: rng.randint(0, max(1, n_ticks // 4)) for p in range(n_pages)}

    for tick in range(n_ticks):
        for p in range(n_pages):
            age = tick - page_created_at[p]
            if age < 0:
                continue
            if age < write_burst_ticks:
                # Guarantee at least one write on the page's creation tick
                # (a page can't be read before it's ever been written), then
                # further burst ticks are probabilistic.
                if age == 0 or rng.random() < 0.8:
                    yield (tick, p, "write")
            elif age < write_burst_ticks + read_decay_ticks:
                decay_age = age - write_burst_ticks
                prob = 0.6 * (0.9 ** decay_age)
                if rng.random() < prob:
                    yield (tick, p, "read")
            # else: silent / archived — no further events


def generate_bursty_trace(n_pages: int, n_ticks: int, write_burst_ticks: int = 5,
                           read_decay_ticks: int = 25, cold_burst_prob: float = 0.15,
                           cold_burst_len_range=(3, 8), cold_burst_read_prob: float = 0.7,
                           seed: int = 7):
    """
    Same ingest-then-decay lifecycle as generate_trace, but after a page
    goes silent it can still receive occasional read bursts against
    otherwise-cold data — modeling an incident-response style query
    hitting week-old logs. No further writes ever occur once a page
    goes silent, so any re-promotion is driven purely by read pressure,
    which is the scenario §6 flags as unresolved.

    Yields (tick, page_id, event) with event in {"write", "read"}.
    """
    rng = random.Random(seed)
    page_created_at = {p: rng.randint(0, max(1, n_ticks // 4)) for p in range(n_pages)}
    # each page independently rolls whether it ever gets a cold-read burst,
    # and if so, when (well after it should already be fully cold)
    cold_burst_start = {}
    cold_burst_end = {}
    for p in range(n_pages):
        if rng.random() < cold_burst_prob:
            silent_at = page_created_at[p] + write_burst_ticks + read_decay_ticks
            start = silent_at + rng.randint(5, 20)
            length = rng.randint(*cold_burst_len_range)
            if start < n_ticks:
                cold_burst_start[p] = start
                cold_burst_end[p] = min(start + length, n_ticks)

    for tick in range(n_ticks):
        for p in range(n_pages):
            age = tick - page_created_at[p]
            if age < 0:
                continue
            if age < write_burst_ticks:
                if age == 0 or rng.random() < 0.8:
                    yield (tick, p, "write")
            elif age < write_burst_ticks + read_decay_ticks:
                decay_age = age - write_burst_ticks
                prob = 0.6 * (0.9 ** decay_age)
                if rng.random() < prob:
                    yield (tick, p, "read")
            elif p in cold_burst_start and cold_burst_start[p] <= tick < cold_burst_end[p]:
                if rng.random() < cold_burst_read_prob:
                    yield (tick, p, "read")
            # else: silent — no further events
