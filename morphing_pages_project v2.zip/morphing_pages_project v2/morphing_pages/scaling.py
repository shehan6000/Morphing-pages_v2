"""
Scaling experiment: does background morphing overhead stay small relative
to total workload time as n_pages grows to 10k+? This is the third
blocking item from the paper's limitations section.
"""
import csv
import time
from pathlib import Path

from .benchmark import run_benchmark

OUT_DIR = Path(__file__).resolve().parent.parent / "results"

PAGE_COUNTS = [200, 1000, 5000, 10000, 20000]


def main():
    rows = []
    for n_pages in PAGE_COUNTS:
        t0 = time.perf_counter()
        summary, _ = run_benchmark(n_pages=n_pages, n_ticks=100, seed=42)
        wall_time = time.perf_counter() - t0
        adaptive = summary["adaptive"]
        morph_pct = (adaptive["morph_cpu_time_s"] / wall_time * 100) if wall_time else 0.0
        rows.append({
            "n_pages": n_pages,
            "wall_time_s": round(wall_time, 4),
            "morph_cpu_time_s": round(adaptive["morph_cpu_time_s"], 4),
            "morph_cpu_pct_of_wall": round(morph_pct, 2),
            "total_transitions": adaptive["total_transitions"],
            "thrash_pages": adaptive["thrash_pages"],
        })
        print(f"n_pages={n_pages:<8} wall={wall_time:7.3f}s  morph_cpu={adaptive['morph_cpu_time_s']:.3f}s "
              f"({morph_pct:5.1f}% of wall)  transitions={adaptive['total_transitions']:<6} "
              f"thrash_pages={adaptive['thrash_pages']}")

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    with open(OUT_DIR / "scaling_experiment.csv", "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    print(f"\nSaved: {OUT_DIR / 'scaling_experiment.csv'}")


if __name__ == "__main__":
    main()
