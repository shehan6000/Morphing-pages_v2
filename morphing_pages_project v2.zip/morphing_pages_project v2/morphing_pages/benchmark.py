"""
Benchmark harness: replay a synthetic trace through the adaptive Page
state machine and the two baseline policies, and report the headline
metrics used in the paper draft (storage footprint over time, read
latency, morph/compression CPU overhead, thrashing rate).
"""
from collections import defaultdict

from .page import Page, TemperatureConfig
from .policies import StaticPolicy, FixedSchedulePolicy
from .workload import make_raw_page, generate_trace


def run_benchmark(n_pages=200, n_ticks=200, seed=42, temp_cfg: TemperatureConfig = None,
                   page_n_values: int = 1024):
    temp_cfg = temp_cfg or TemperatureConfig()

    raw_by_page = {p: make_raw_page(n_values=page_n_values, seed=seed + p) for p in range(n_pages)}
    trace = list(generate_trace(n_pages, n_ticks, seed=seed))

    # Pages are created lazily, on their first event in the trace — not all
    # up front — so a page's temperature only starts decaying once it
    # actually exists. Creating everything at tick 0 would let unborn pages
    # "pre-decay" to COLD before their real write burst, producing a spurious
    # extra demote/promote cycle and inflated thrash counts.
    adaptive_pages = {}
    static = StaticPolicy(raw_by_page)
    fixed = FixedSchedulePolicy(raw_by_page, compress_after=20)

    metrics = {
        "adaptive": defaultdict(list),
        "static-uncompressed": defaultdict(list),
        "fixed-schedule": defaultdict(list),
    }

    events_by_tick = defaultdict(list)
    for tick, page_id, event in trace:
        events_by_tick[tick].append((page_id, event))

    thrash_counter = defaultdict(int)  # page_id -> transition count (adaptive only)

    for tick in range(n_ticks):
        for page_id, event in events_by_tick.get(tick, []):
            if page_id not in adaptive_pages:
                adaptive_pages[page_id] = Page(page_id, raw_by_page[page_id], temp_cfg)

            if event == "write":
                adaptive_pages[page_id].on_write(tick)
                static.on_write(tick, page_id)
                fixed.on_write(tick, page_id)
            elif page_id in static.encoded:  # read: cost model is decode latency of current encoding
                # (guard: a page can't be read before its first write ever landed)
                adaptive_pages[page_id].on_read(tick)
                metrics["adaptive"]["read_latency_s"].append(adaptive_pages[page_id].encoded.decode_time_s)
                metrics["static-uncompressed"]["read_latency_s"].append(static.encoded[page_id].decode_time_s)
                metrics["fixed-schedule"]["read_latency_s"].append(fixed.encoded[page_id].decode_time_s)

        for page_id, pg in adaptive_pages.items():
            before = pg.state
            pg.tick(tick)
            if pg.state != before:
                thrash_counter[page_id] += 1
        fixed.tick(tick)

        metrics["adaptive"]["total_bytes"].append(sum(pg.encoded.encoded_bytes for pg in adaptive_pages.values()))
        metrics["static-uncompressed"]["total_bytes"].append(sum(e.encoded_bytes for e in static.encoded.values()))
        metrics["fixed-schedule"]["total_bytes"].append(sum(e.encoded_bytes for e in fixed.encoded.values()))

    raw_total = sum(len(r) for r in raw_by_page.values())

    summary = {}
    for name, m in metrics.items():
        reads = m["read_latency_s"]
        sizes = m["total_bytes"]
        summary[name] = {
            "avg_read_latency_us": (sum(reads) / len(reads) * 1e6) if reads else 0.0,
            "final_storage_bytes": sizes[-1] if sizes else 0,
            "final_storage_vs_raw_pct": (sizes[-1] / raw_total * 100) if sizes else 0.0,
        }

    summary["adaptive"]["morph_cpu_time_s"] = sum(pg.morph_cpu_time_s for pg in adaptive_pages.values())
    summary["static-uncompressed"]["morph_cpu_time_s"] = static.morph_cpu_time_s
    summary["fixed-schedule"]["morph_cpu_time_s"] = fixed.morph_cpu_time_s

    summary["adaptive"]["total_transitions"] = sum(len(pg.transitions) for pg in adaptive_pages.values())
    summary["adaptive"]["thrash_pages"] = sum(1 for c in thrash_counter.values() if c > 3)

    return summary, metrics
