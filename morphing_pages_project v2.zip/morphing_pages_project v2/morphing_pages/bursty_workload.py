"""
Bursty cold-read workload generator — a structurally different trace
from workload.py's monotonic write-then-decay pattern. Models an
"incident investigation" access pattern: a page goes fully cold (no
writes, no reads for a long stretch), then receives a sudden burst of
reads much later, then goes quiet again. This is the workload shape
needed to test whether COLD pages should ever re-promote to WARM
without a write forcing it.
"""
import random

from .workload import make_raw_page  # reused as-is


def generate_bursty_trace(n_pages: int, n_ticks: int, write_burst_ticks: int = 5,
                           initial_read_ticks: int = 15, cold_silence_ticks: int = 30,
                           spike_ticks: int = 10, spike_read_prob: float = 0.9,
                           seed: int = 7):
    """
    Per-page lifecycle: write burst -> short initial read window -> long
    cold silence (page has fully decayed to COLD) -> a sudden read spike
    (the "incident investigation") -> quiet again.

    Yields (tick, page_id, event) with event in {"write", "read"}.
    """
    rng = random.Random(seed)
    page_created_at = {p: rng.randint(0, max(1, n_ticks // 6)) for p in range(n_pages)}
    # Not every page gets a later spike — only a subset, to also exercise
    # pages that stay cold with no re-promotion pressure at all.
    spike_pages = {p for p in range(n_pages) if rng.random() < 0.4}
    spike_start_offset = write_burst_ticks + initial_read_ticks + cold_silence_ticks

    for tick in range(n_ticks):
        for p in range(n_pages):
            age = tick - page_created_at[p]
            if age < 0:
                continue
            if age < write_burst_ticks:
                if age == 0 or rng.random() < 0.8:
                    yield (tick, p, "write")
            elif age < write_burst_ticks + initial_read_ticks:
                if rng.random() < 0.5:
                    yield (tick, p, "read")
            elif age < spike_start_offset:
                pass  # cold silence — page fully decays to COLD here
            elif p in spike_pages and age < spike_start_offset + spike_ticks:
                if rng.random() < spike_read_prob:
                    yield (tick, p, "read")
            # else: quiet again, or never spiked at all
