"""
Parameter sensitivity sweep: decay rate, hysteresis window, demote
threshold. Reports read-latency speedup vs. fixed-schedule, final
storage efficiency, and thrash rate across the grid — needed to defend
that the headline result in the paper isn't overfit to one configuration.
"""
import csv
import itertools
from pathlib import Path

from .benchmark import run_benchmark
from .page import TemperatureConfig

OUT_DIR = Path(__file__).resolve().parent.parent / "results"

DECAY_VALUES = [0.85, 0.90, 0.95]
HYSTERESIS_VALUES = [1, 3, 5]
THRESHOLD_VALUES = [0.3, 0.5, 0.7]


def run_sweep(n_pages=200, n_ticks=200, seed=42):
    rows = []
    for decay, hyst, thresh in itertools.product(DECAY_VALUES, HYSTERESIS_VALUES, THRESHOLD_VALUES):
        cfg = TemperatureConfig(decay=decay, hysteresis_ticks=hyst, demote_threshold=thresh)
        summary, _ = run_benchmark(n_pages=n_pages, n_ticks=n_ticks, seed=seed, temp_cfg=cfg)
        adaptive = summary["adaptive"]
        fixed = summary["fixed-schedule"]
        speedup = (fixed["avg_read_latency_us"] / adaptive["avg_read_latency_us"]
                   if adaptive["avg_read_latency_us"] else float("inf"))
        rows.append({
            "decay": decay,
            "hysteresis_ticks": hyst,
            "demote_threshold": thresh,
            "adaptive_read_latency_us": round(adaptive["avg_read_latency_us"], 4),
            "fixed_read_latency_us": round(fixed["avg_read_latency_us"], 4),
            "latency_speedup_x": round(speedup, 2),
            "adaptive_storage_pct": round(adaptive["final_storage_vs_raw_pct"], 2),
            "fixed_storage_pct": round(fixed["final_storage_vs_raw_pct"], 2),
            "total_transitions": adaptive["total_transitions"],
            "thrash_pages": adaptive["thrash_pages"],
        })
    return rows


def main():
    rows = run_sweep()
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    with open(OUT_DIR / "sensitivity_sweep.csv", "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)

    print(f"\n=== Sensitivity sweep: {len(rows)} configurations ===\n")
    header = f"{'decay':<8}{'hyst':<6}{'thresh':<8}{'speedup(x)':<12}{'storage%':<10}{'thrash_pages':<14}"
    print(header)
    print("-" * len(header))
    for r in rows:
        print(f"{r['decay']:<8}{r['hysteresis_ticks']:<6}{r['demote_threshold']:<8}"
              f"{r['latency_speedup_x']:<12.2f}{r['adaptive_storage_pct']:<10.2f}{r['thrash_pages']:<14}")

    speedups = [r["latency_speedup_x"] for r in rows]
    thrash_configs = [r for r in rows if r["thrash_pages"] > 0]
    print(f"\nSpeedup range across grid: {min(speedups):.2f}x - {max(speedups):.2f}x")
    print(f"Configs with any thrashing: {len(thrash_configs)}/{len(rows)}")
    if thrash_configs:
        print("Thrashing occurs at: " + ", ".join(
            f"(decay={r['decay']}, hyst={r['hysteresis_ticks']}, thresh={r['demote_threshold']})"
            for r in thrash_configs))

    print(f"\nSaved: {OUT_DIR / 'sensitivity_sweep.csv'}")


if __name__ == "__main__":
    main()
