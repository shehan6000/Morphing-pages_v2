"""
Encoding simulation for the three page states.

Uses zlib at different compression levels, plus a delta transform before
COLD compression, as a stand-in for the production pipeline (dictionary +
bit-packing for WARM, delta/RLE + heavy compression for COLD). This gives
*real* compression ratios and *real* (de)compression latency on synthetic
column data without requiring a full storage-engine implementation to get
believable numbers for early benchmarking.
"""
import struct
import time
import zlib
from dataclasses import dataclass
from enum import Enum


class PageState(Enum):
    HOT = "hot"    # row-major / uncompressed, write-optimized
    WARM = "warm"   # columnar, dictionary + bit-packing (light compression)
    COLD = "cold"    # delta + heavy compression, read-optimized


# zlib compression level used to stand in for each state's encoding pipeline.
# 0 = store only (HOT), 3 = light/fast (WARM), 9 = max (COLD).
_COMPRESSION_LEVEL = {
    PageState.HOT: 0,
    PageState.WARM: 3,
    PageState.COLD: 9,
}


@dataclass
class EncodedPage:
    state: PageState
    raw_bytes: int
    encoded_bytes: int
    encode_time_s: float
    decode_time_s: float


def _delta_encode(raw: bytes) -> bytes:
    """Delta transform over 8-byte float64 slots, applied before COLD
    compression to mimic a delta/RLE-friendly encoding pipeline."""
    n = len(raw) // 8
    floats = struct.unpack(f"<{n}d", raw[: n * 8])
    if n == 0:
        return raw
    out = [floats[0]] + [floats[i] - floats[i - 1] for i in range(1, n)]
    return struct.pack(f"<{n}d", *out)


def encode_page(raw: bytes, state: PageState) -> EncodedPage:
    level = _COMPRESSION_LEVEL[state]
    payload = raw

    t0 = time.perf_counter()
    if state == PageState.COLD:
        payload = _delta_encode(raw)
    compressed = zlib.compress(payload, level) if level > 0 else payload
    encode_time = time.perf_counter() - t0

    t0 = time.perf_counter()
    if level > 0:
        zlib.decompress(compressed)
    decode_time = time.perf_counter() - t0

    return EncodedPage(
        state=state,
        raw_bytes=len(raw),
        encoded_bytes=len(compressed),
        encode_time_s=encode_time,
        decode_time_s=decode_time,
    )
