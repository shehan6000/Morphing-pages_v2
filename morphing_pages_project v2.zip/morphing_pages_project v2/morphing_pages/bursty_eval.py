"""
Evaluates the cold-read re-promotion rule (Page.on_read, gated by
TemperatureConfig.enable_cold_repromotion) against the bursty
cold-read trace. This is the experiment that resolves the §6 design
gap: does sustained read pressure on cold data get served at
reasonable latency, without over-promoting on isolated cold reads?
"""
import csv
from collections import defaultdict
from pathlib import Path

from .page import Page, TemperatureConfig
from .policies import StaticPolicy, FixedSchedulePolicy
from .workload import make_raw_page, generate_bursty_trace

OUT_DIR = Path(__file__).resolve().parent.parent / "results"


def run_bursty(n_pages=200, n_ticks=250, seed=7, enable_repromotion=False,
                cold_read_promote_threshold=3.0):
    raw_by_page = {p: make_raw_page(seed=seed + p) for p in range(n_pages)}
    trace = list(generate_bursty_trace(n_pages, n_ticks, seed=seed))

    cfg = TemperatureConfig(
        enable_cold_repromotion=enable_repromotion,
        cold_read_promote_threshold=cold_read_promote_threshold,
    )
    adaptive_pages = {}
    static = StaticPolicy(raw_by_page)
    fixed = FixedSchedulePolicy(raw_by_page, compress_after=20)

    events_by_tick = defaultdict(list)
    for tick, page_id, event in trace:
        events_by_tick[tick].append((page_id, event))

    # Separately track read latency during cold-burst windows only —
    # that's the metric that actually matters for this experiment.
    cold_burst_read_latencies = {"adaptive": [], "static-uncompressed": [], "fixed-schedule": []}
    all_read_latencies = {"adaptive": [], "static-uncompressed": [], "fixed-schedule": []}
    repromotion_events = 0
    unnecessary_repromotions = 0  # promoted but page never read again afterward (wasted work)

    # Precompute, per page, the set of ticks that fall inside a cold burst
    # (recomputed here since generate_bursty_trace doesn't expose it directly)
    import random as _random
    rng = _random.Random(seed)
    page_created_at = {p: rng.randint(0, max(1, n_ticks // 4)) for p in range(n_pages)}
    write_burst_ticks, read_decay_ticks = 5, 25
    cold_burst_windows = {}
    for p in range(n_pages):
        if rng.random() < 0.15:
            silent_at = page_created_at[p] + write_burst_ticks + read_decay_ticks
            start = silent_at + rng.randint(5, 20)
            length = rng.randint(3, 8)
            if start < n_ticks:
                cold_burst_windows[p] = (start, min(start + length, n_ticks))

    for tick in range(n_ticks):
        for page_id, event in events_by_tick.get(tick, []):
            if page_id not in adaptive_pages:
                adaptive_pages[page_id] = Page(page_id, raw_by_page[page_id], cfg)

            in_cold_burst = page_id in cold_burst_windows and cold_burst_windows[page_id][0] <= tick < cold_burst_windows[page_id][1]

            if event == "write":
                adaptive_pages[page_id].on_write(tick)
                static.on_write(tick, page_id)
                fixed.on_write(tick, page_id)
            elif page_id in static.encoded:
                lat_a = adaptive_pages[page_id].encoded.decode_time_s
                adaptive_pages[page_id].on_read(tick)
                lat_s = static.encoded[page_id].decode_time_s
                lat_f = fixed.encoded[page_id].decode_time_s
                all_read_latencies["adaptive"].append(lat_a)
                all_read_latencies["static-uncompressed"].append(lat_s)
                all_read_latencies["fixed-schedule"].append(lat_f)
                if in_cold_burst:
                    cold_burst_read_latencies["adaptive"].append(lat_a)
                    cold_burst_read_latencies["static-uncompressed"].append(lat_s)
                    cold_burst_read_latencies["fixed-schedule"].append(lat_f)

        for pg in adaptive_pages.values():
            pg.tick(tick)
        fixed.tick(tick)

    repromotion_events = sum(
        1 for pg in adaptive_pages.values() for (_, frm, to) in pg.transitions
        if frm.value == "cold" and to.value == "warm"
    )

    def avg(lst):
        return (sum(lst) / len(lst) * 1e6) if lst else 0.0

    return {
        "enable_repromotion": enable_repromotion,
        "avg_read_latency_all_us": avg(all_read_latencies["adaptive"]),
        "avg_read_latency_cold_burst_us": avg(cold_burst_read_latencies["adaptive"]),
        "fixed_avg_read_latency_cold_burst_us": avg(cold_burst_read_latencies["fixed-schedule"]),
        "static_avg_read_latency_cold_burst_us": avg(cold_burst_read_latencies["static-uncompressed"]),
        "pages_with_cold_burst": len(cold_burst_windows),
        "repromotion_events": repromotion_events,
        "total_transitions": sum(len(pg.transitions) for pg in adaptive_pages.values()),
    }


def main():
    off = run_bursty(enable_repromotion=False)
    on = run_bursty(enable_repromotion=True)

    print("\n=== Bursty cold-read workload: re-promotion off vs on ===\n")
    print(f"Pages with a cold-read burst: {off['pages_with_cold_burst']}\n")

    header = f"{'config':<18}{'cold-burst read lat (us)':<26}{'repromotion events':<20}{'total transitions':<20}"
    print(header)
    print("-" * len(header))
    print(f"{'repromo OFF':<18}{off['avg_read_latency_cold_burst_us']:<26.2f}{off['repromotion_events']:<20}{off['total_transitions']:<20}")
    print(f"{'repromo ON':<18}{on['avg_read_latency_cold_burst_us']:<26.2f}{on['repromotion_events']:<20}{on['total_transitions']:<20}")
    print(f"{'fixed-schedule':<18}{off['fixed_avg_read_latency_cold_burst_us']:<26.2f}{'n/a':<20}{'n/a':<20}")
    print(f"{'static':<18}{off['static_avg_read_latency_cold_burst_us']:<26.2f}{'n/a':<20}{'n/a':<20}")

    improvement = (off['avg_read_latency_cold_burst_us'] / on['avg_read_latency_cold_burst_us']
                   if on['avg_read_latency_cold_burst_us'] else float('inf'))
    print(f"\nRe-promotion reduces cold-burst read latency by {improvement:.2f}x "
          f"({off['repromotion_events']} -> {on['repromotion_events']} repromotion events)")

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    with open(OUT_DIR / "bursty_cold_read_experiment.csv", "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(off.keys()))
        writer.writeheader()
        writer.writerows([off, on])
    print(f"\nSaved: {OUT_DIR / 'bursty_cold_read_experiment.csv'}")


if __name__ == "__main__":
    main()
