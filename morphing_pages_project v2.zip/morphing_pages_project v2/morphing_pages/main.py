"""
CLI entry point: run the benchmark, print a summary table, and save
results (JSON summary, CSV timeseries, PNG chart) for use in the paper.
"""
import csv
import json
from pathlib import Path

from .benchmark import run_benchmark

OUT_DIR = Path(__file__).resolve().parent.parent / "results"


def main():
    summary, metrics = run_benchmark(n_pages=200, n_ticks=200)

    print("\n=== Morphing Pages Benchmark: adaptive vs. baselines ===\n")
    header = f"{'policy':<22}{'avg read lat (us)':<20}{'final size (% raw)':<20}{'morph cpu (s)':<16}"
    print(header)
    print("-" * len(header))
    for name in ("adaptive", "static-uncompressed", "fixed-schedule"):
        s = summary[name]
        print(f"{name:<22}{s['avg_read_latency_us']:<20.2f}{s['final_storage_vs_raw_pct']:<20.2f}{s['morph_cpu_time_s']:<16.4f}")

    print(f"\nAdaptive-only: {summary['adaptive']['total_transitions']} total state transitions, "
          f"{summary['adaptive']['thrash_pages']} pages thrashed (>3 flips)")

    OUT_DIR.mkdir(parents=True, exist_ok=True)

    with open(OUT_DIR / "benchmark_summary.json", "w") as f:
        json.dump(summary, f, indent=2)

    n_ticks = len(metrics["adaptive"]["total_bytes"])
    with open(OUT_DIR / "storage_footprint_timeseries.csv", "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["tick", "adaptive_bytes", "static_bytes", "fixed_schedule_bytes"])
        for t in range(n_ticks):
            writer.writerow([
                t,
                metrics["adaptive"]["total_bytes"][t],
                metrics["static-uncompressed"]["total_bytes"][t],
                metrics["fixed-schedule"]["total_bytes"][t],
            ])

    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        ticks = list(range(n_ticks))
        plt.figure(figsize=(8, 5))
        plt.plot(ticks, metrics["adaptive"]["total_bytes"], label="adaptive (morphing)")
        plt.plot(ticks, metrics["static-uncompressed"]["total_bytes"], label="static uncompressed")
        plt.plot(ticks, metrics["fixed-schedule"]["total_bytes"], label="fixed-schedule (Timescale-like)")
        plt.xlabel("tick")
        plt.ylabel("total encoded bytes")
        plt.title("Storage footprint over time")
        plt.legend()
        plt.tight_layout()
        plt.savefig(OUT_DIR / "storage_footprint.png", dpi=150)
        print(f"\nSaved: {OUT_DIR / 'storage_footprint.png'}")
    except ImportError:
        print("\n(matplotlib not available — skipped chart)")

    print(f"Saved: {OUT_DIR / 'benchmark_summary.json'}")
    print(f"Saved: {OUT_DIR / 'storage_footprint_timeseries.csv'}")


if __name__ == "__main__":
    main()
