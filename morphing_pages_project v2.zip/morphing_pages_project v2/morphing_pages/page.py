"""
Page: temperature tracking + hysteresis-guarded state machine.

This is the core contribution being benchmarked: each page independently
decides, from its own observed access recency, whether to demote to a
more compressed encoding or promote back to a write-optimized one.
"""
from dataclasses import dataclass, field

from .encoding import PageState, encode_page


@dataclass
class TemperatureConfig:
    decay: float = 0.90           # temperature *= decay, applied once per tick
    read_weight: float = 1.0
    write_weight: float = 3.0     # writes matter more than reads for "hotness"
    demote_threshold: float = 0.5
    hysteresis_ticks: int = 3     # consecutive below-threshold ticks required to demote

    # Cold-read re-promotion (resolves the §6 "bursty cold read" design gap).
    # Disabled by default so it doesn't change the §4.2-4.4 results, which
    # were validated without it.
    enable_cold_repromotion: bool = False
    cold_read_weight: float = 1.0
    cold_read_promote_threshold: float = 3.0


class Page:
    def __init__(self, page_id: int, raw_bytes: bytes, cfg: TemperatureConfig):
        self.page_id = page_id
        self.raw = raw_bytes
        self.cfg = cfg
        self.state = PageState.HOT
        self.temperature = cfg.write_weight  # starts hot: just written
        self._below_threshold_streak = 0
        self.cold_read_pressure = 0.0
        self.transitions = []  # (tick, from_state, to_state)
        self.morph_cpu_time_s = 0.0
        self.encoded = encode_page(raw_bytes, self.state)

    def _reencode(self, new_state: PageState, tick: int):
        enc = encode_page(self.raw, new_state)
        self.morph_cpu_time_s += enc.encode_time_s
        self.transitions.append((tick, self.state, new_state))
        if self.state == PageState.COLD:
            self.cold_read_pressure = 0.0
        self.state = new_state
        self.encoded = enc

    def on_write(self, tick: int):
        """A write always promotes immediately back to HOT — this is the
        copy-on-write path in the real system; here we just re-encode."""
        self.temperature += self.cfg.write_weight
        self._below_threshold_streak = 0
        if self.state != PageState.HOT:
            self._reencode(PageState.HOT, tick)

    def on_read(self, tick: int):
        self.temperature += self.cfg.read_weight
        if self.cfg.enable_cold_repromotion and self.state == PageState.COLD:
            self.cold_read_pressure += self.cfg.cold_read_weight
            if self.cold_read_pressure >= self.cfg.cold_read_promote_threshold:
                # Sustained read pressure on a cold page re-promotes to WARM
                # (not HOT — there has been no write, so no write-optimized
                # layout is warranted, only cheaper decode).
                self._reencode(PageState.WARM, tick)
                self._below_threshold_streak = 0

    def tick(self, tick: int):
        """Advance one time step: decay temperature, evaluate demotion
        under the hysteresis guard so bursty access doesn't cause thrash."""
        self.temperature *= self.cfg.decay
        if self.temperature < self.cfg.demote_threshold:
            self._below_threshold_streak += 1
        else:
            self._below_threshold_streak = 0

        if self.cfg.enable_cold_repromotion and self.state == PageState.COLD:
            self.cold_read_pressure *= self.cfg.decay

        if self._below_threshold_streak >= self.cfg.hysteresis_ticks:
            if self.state == PageState.HOT:
                self._reencode(PageState.WARM, tick)
            elif self.state == PageState.WARM:
                self._reencode(PageState.COLD, tick)
            self._below_threshold_streak = 0
